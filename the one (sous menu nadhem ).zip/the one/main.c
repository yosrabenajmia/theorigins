#include "menu.h"
#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
int main()
{

   

    int menu1 = 1;
    int menu2 = 0;


    SDL_Surface* screen;


    int boucle = 1;


    SDL_Event event;


    background back_menu;


    boutton oui, non,charger,nouvel,ques,ques1,ques2,rep1,rep2,rep3,bbb,bb;


    Mix_Music *musique;
    Mix_Chunk *song_bref;
   

    text txt_menu,txt_menu2;
    text txt_sauv,tq,tp,tt,r1,r2,r3,back,qq;


   
    TTF_Init();
    screen = SDL_SetVideoMode(1100, 1200, 32, SDL_HWSURFACE | SDL_SRCALPHA);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024);


    initialiser_textMenu(&txt_menu,"quiz",450,291);
	initialiser_textMenu(&txt_menu2,"puzzle",640,291);
initialiser_textMenu(&tp,"CHOIX A",550,291);
initialiser_textMenu(&tq,"CHOIX B",550,461);
initialiser_textMenu(&tt,"CHOIX C",550,625);
initialiser_textMenu(&r1,"reponse1",500,376);
initialiser_textMenu(&r2,"reponse2",500,550);
initialiser_textMenu(&r3,"reponse3",500,700);
initialiser_textMenu(&back,"BACK",35,20);
initialiser_textMenuq(&qq,"QUIZ",450,20);
    initialiser_textMenu2(&txt_sauv);
    initialiser_backmenu(&back_menu);
	initialiser_ques(&ques,465,120);
	initialiser_ques(&ques1,275,120);
	initialiser_ques(&ques2,630,120);
	initialiser_ques(&rep1,500,376);
	initialiser_ques(&rep2,500,550);
	initialiser_ques(&rep3,500,700);
	initialiser_bbb(&bbb);
	initialiser_bb(&bb);
    initialiser_oui(&oui);  
    initialiser_non(&non);  
    initialiser_charger(&charger);
    initialiser_nouvel(&nouvel);


    musique = Mix_LoadMUS("background_music.mp3");
    
    song_bref = Mix_LoadWAV("button_music.ogg");


    while (boucle == 1)
    {
        if (menu1 == 1)
        {

            afficher_back(screen, back_menu);
            afficher_btn(screen, oui);
            afficher_btn(screen, non);
            afficher_txt(screen, txt_menu);
afficher_txt(screen, txt_menu2);
        }
        else if(menu2==1){
            afficher_back(screen, back_menu);
afficher_btn(screen,bbb);
afficher_btn(screen,bb);
            afficher_btn(screen, charger);
            afficher_btn(screen, nouvel);
		afficher_btn(screen, ques);
		afficher_btn(screen, ques1);
		afficher_btn(screen, ques2);
		afficher_btn(screen, rep1);
		afficher_btn(screen, rep2);
		afficher_btn(screen, rep3);
            afficher_txt(screen, txt_sauv);
afficher_txt(screen, tq);
afficher_txt(screen, tp);
afficher_txt(screen, tt);
afficher_txt(screen, r1);
afficher_txt(screen, r2);
afficher_txt(screen, r3);
afficher_txt(screen, qq);
afficher_txt(screen, back);
         }

        SDL_Flip(screen);


        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
		case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE) {
                boucle=0;
            		}
		break;
                case SDL_QUIT:
                    boucle = 0;
                    break;
               
                case SDL_MOUSEMOTION:
                    if (menu1 == 1)
                    {Mix_HaltMusic();

                        if (event.motion.x >= oui.pos.x && event.motion.x <= oui.pos.x + oui.pos.w &&
   			 event.motion.y >= oui.pos.y && event.motion.y <= oui.pos.y + oui.pos.h)
                        {
                            oui.p =1;
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else if (event.motion.x > non.pos.x && event.motion.x < non.pos.x + non.pos.w
                            && event.motion.y > non.pos.y && event.motion.y < non.pos.y + non.pos.h)
                        {
                            non.p = 1;  
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else
                        {
                            oui.p = 0;  
                            non.p = 0;  
                        }
                    }
                    else if (menu2 == 1)
                    {Mix_PlayMusic(musique, -1);
                        if (event.motion.x >= charger.pos.x && event.motion.x <= charger.pos.x + charger.pos.w
                            && event.motion.y >= charger.pos.y && event.motion.y <= charger.pos.y + charger.pos.h)
                        {
                            charger.p = 1;  
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else if (event.motion.x >= nouvel.pos.x && event.motion.x <= nouvel.pos.x + nouvel.pos.w
                            && event.motion.y >= nouvel.pos.y && event.motion.y <= nouvel.pos.y + nouvel.pos.h)
                        {
                            nouvel.p = 1;  
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
			else if (event.motion.x >= bbb.pos.x && event.motion.x <= bbb.pos.x + bbb.pos.w
                            && event.motion.y >= bbb.pos.y && event.motion.y <= bbb.pos.y + bbb.pos.h)
                        {
                            bbb.p = 1;  
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
			else if (event.motion.x >= bb.pos.x && event.motion.x <= bb.pos.x + bb.pos.w
                            && event.motion.y >= bb.pos.y && event.motion.y <= bb.pos.y + bb.pos.h)
                        {
                            bb.p = 1;  
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else
                        {
                            charger.p = 0;  
                            nouvel.p = 0;
				bbb.p = 0;
				bb.p=0;  
                        }
                    }
                    break;
               
                case SDL_MOUSEBUTTONUP:
                    if (menu1==1){
                        if(event.motion.x > oui.pos.x && event.motion.x < oui.pos.x + oui.pos.w
                            && event.motion.y > oui.pos.y && event.motion.y < oui.pos.y + oui.pos.h){
                             menu1=0;
                             menu2=1;
                          }
                          }
		else if(menu2==1){
			if(event.motion.x > bb.pos.x && event.motion.x < bb.pos.x + bb.pos.w
                            && event.motion.y > bb.pos.y && event.motion.y < bb.pos.y + bb.pos.h){
                             menu1=1;
                             menu2=0;
			}
                   
                       
                    }
             

                    break;

                default:
                    break;
            }
	}
	}
        return 0;}
