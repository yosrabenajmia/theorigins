#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include"menu.h"

void initialiser_ques(boutton *oui,int f,int ff)
{
oui->img[0]=IMG_Load("quiz.png");
oui->pos.x=f;
oui->pos.y=ff;
oui->pos.h=20;
oui->pos.w=20;
oui->p=0;
}
void initialiser_oui(boutton *oui)
{
oui->img[0]=IMG_Load("play.png");
oui->img[1]=IMG_Load("plays.png");
oui->pos.x=400;
oui->pos.y=291;
oui->pos.h=100;
oui->pos.w=100;
oui->p=0;
}
void initialiser_non(boutton *non)
{
non->img[0]=IMG_Load("SETTINGS.png");
non->img[1]=IMG_Load("settingss.png");
non->pos.x=600;
non->pos.y=291;
non->pos.h=100;
non->pos.w=100;
non->p=0;
}
void initialiser_charger(boutton *charger)
{
charger->img[0]=IMG_Load("play.png");
charger->img[1]=IMG_Load("plays.png");
charger->pos.x=500;
charger->pos.y=291;
charger->pos.h=100;
charger->pos.w=100;
charger->p=0;
}
void initialiser_bbb(boutton *bbb)
{
bbb->img[0]=IMG_Load("play.png");
bbb->img[1]=IMG_Load("plays.png");
bbb->pos.x=500;
bbb->pos.y=625;
bbb->pos.h=100;
bbb->pos.w=100;
bbb->p=0;
}
void initialiser_bb(boutton *bb)
{
bb->img[0]=IMG_Load("play.png");
bb->img[1]=IMG_Load("plays.png");
bb->pos.x=10;
bb->pos.y=10;
bb->pos.h=100;
bb->pos.w=100;
bb->p=0;
}
void initialiser_nouvel(boutton *nouvel)
{
nouvel->img[0]=IMG_Load("SETTINGS.png");
nouvel->img[1]=IMG_Load("settingss.png");
nouvel->pos.x=500;
nouvel->pos.y=461;
nouvel->pos.h=100;
nouvel->pos.w=100;
nouvel->p=0;
}
void initialiser_backmenu(background *back) {
    back->photo = 0;
    back->img[0] = IMG_Load("background.jpeg");
       
    
    back->pos1.x = 0;
    back->pos1.y = 0;
}
void afficher_btn(SDL_Surface *screen,boutton btn)
{
SDL_BlitSurface(btn.img[btn.p],NULL,screen,&btn.pos);
}
void afficher_back(SDL_Surface *screen,background b)
{
SDL_BlitSurface(b.img[0],NULL,screen,&b.pos1);
}
void initialiser_textMenu(text *t,char ch[],int a,int b)
{

    t->pos.x = a;
    t->pos.y = b;


    t->color.r = 255;
    t->color.g = 255;
    t->color.b = 255;


    t->police = TTF_OpenFont("arial.ttf", 20);
    if (t->police == NULL) {
        printf("Erreur : Impossible de charger la police ! %s\n", TTF_GetError());
        return;
    }


    strcpy(t->nom, ch); 


    t->txt = TTF_RenderText_Blended(t->police, t->nom, t->color);
    if (t->txt == NULL) {
        printf("Erreur : Impossible de créer la surface du texte ! %s\n", TTF_GetError());
    }
}
void initialiser_textMenuq(text *t,char ch[],int a,int b)
{

    t->pos.x = a;
    t->pos.y = b;


    t->color.r = 255;
    t->color.g = 255;
    t->color.b = 255;


    t->police = TTF_OpenFont("arial.ttf", 100);
    if (t->police == NULL) {
        printf("Erreur : Impossible de charger la police ! %s\n", TTF_GetError());
        return;
    }


    strcpy(t->nom, ch); 


    t->txt = TTF_RenderText_Blended(t->police, t->nom, t->color);
    if (t->txt == NULL) {
        printf("Erreur : Impossible de créer la surface du texte ! %s\n", TTF_GetError());
    }
}
void initialiser_textMenu2(text *t)
{

    t->pos.x = 500;
    t->pos.y = 135;


    t->color.r = 255;
    t->color.g = 255;
    t->color.b = 255;


    t->police = TTF_OpenFont("arial.ttf", 20);
    if (t->police == NULL) {
        printf("Erreur : Impossible de charger la police ! %s\n", TTF_GetError());
        return;
    }


    strcpy(t->nom, "QUESTION??"); 


    t->txt = TTF_RenderText_Blended(t->police, t->nom, t->color);
    if (t->txt == NULL) {
        printf("Erreur : Impossible de créer la surface du texte ! %s\n", TTF_GetError());
    }
}


void afficher_txt(SDL_Surface *screen,text txt)
{
        SDL_BlitSurface(txt.txt , NULL , screen, &txt.pos);
}



void liberer_button(boutton * btn)
{
SDL_FreeSurface(btn->img[0]);
SDL_FreeSurface(btn->img[1]);

}
void liberer_back(background * back)
{
SDL_FreeSurface(back->img[0]);
}
void liberer_texte(text *t)
{
SDL_FreeSurface(t->txt);
TTF_CloseFont(t->police);

}

