#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include"sauvgarde.h"

void initialiser_oui(boutton *oui)
{
oui->img[0]=IMG_Load("image/oui1.png");
oui->img[1]=IMG_Load("image/oui2.png");
oui->pos.x=999;
oui->pos.y=291;
oui->pos.h=170;
oui->pos.w=400;
oui->p=0;
}
void initialiser_non(boutton *non)
{
non->img[0]=IMG_Load("image/non1.png");
non->img[1]=IMG_Load("image/non2.png");
non->pos.x=999;
non->pos.y=461;
non->pos.h=170;
non->pos.w=400;
non->p=0;
}
void initialiser_charger(boutton *charger)
{
charger->img[0]=IMG_Load("image/charger1.png");
charger->img[1]=IMG_Load("image/charger2.png");
charger->pos.x=999;
charger->pos.y=291;
charger->pos.h=170;
charger->pos.w=400;
charger->p=0;
}
void initialiser_nouvel(boutton *nouvel)
{
nouvel->img[0]=IMG_Load("image/nouvelle1.png");
nouvel->img[1]=IMG_Load("image/nouvelle2.png");
nouvel->pos.x=999;
nouvel->pos.y=461;
nouvel->pos.h=170;
nouvel->pos.w=400;
nouvel->p=0;
}
void initialiser_backmenu(background *back) {
    back->photo = 0;
    back->nbr = 12;  // Nombre d'images du background
    for (int i = 0; i < back->nbr; i++) {
        back->img[i] = IMG_Load("image/interface.png");
       
    }
    back->pos1.x = 0;
    back->pos1.y = 0;
}
void afficher_btn(SDL_Surface *screen,boutton btn)
{
SDL_BlitSurface(btn.img[btn.p],NULL,screen,&btn.pos);
}
void afficher_back(SDL_Surface *screen,background b)
{
SDL_BlitSurface(b.img[b.photo],NULL,screen,&b.pos1);
}
void initialiser_textMenu(text *t)
{
    // Position du texte
    t->pos.x = 520;
    t->pos.y = 135;

    // Couleur blanche du texte (RGB : 255,255,255)
    t->color.r = 255;
    t->color.g = 255;
    t->color.b = 255;

    // Charger la police
    t->police = TTF_OpenFont("police/Ubuntu-Bold(1).ttf", 20);
    if (t->police == NULL) {
        printf("Erreur : Impossible de charger la police ! %s\n", TTF_GetError());
        return;
    }

    // Texte à afficher
    strcpy(t->nom, "Voulez-vous sauvegarder ?"); // Assurez-vous que `text` a un champ `char nom[256]`

    // Créer la surface de texte
    t->txt = TTF_RenderText_Blended(t->police, t->nom, t->color);
    if (t->txt == NULL) {
        printf("Erreur : Impossible de créer la surface du texte ! %s\n", TTF_GetError());
    }
}
void initialiser_textMenu2(text *t)
{
    // Position du texte
    t->pos.x = 520;
    t->pos.y = 135;

    // Couleur blanche du texte (RGB : 255,255,255)
    t->color.r = 255;
    t->color.g = 255;
    t->color.b = 255;

    // Charger la police
    t->police = TTF_OpenFont("police/Ubuntu-Bold(1).ttf", 20);
    if (t->police == NULL) {
        printf("Erreur : Impossible de charger la police ! %s\n", TTF_GetError());
        return;
    }

    // Texte à afficher
    strcpy(t->nom, "choisir boutton"); // Assurez-vous que `text` a un champ `char nom[256]`

    // Créer la surface de texte
    t->txt = TTF_RenderText_Blended(t->police, t->nom, t->color);
    if (t->txt == NULL) {
        printf("Erreur : Impossible de créer la surface du texte ! %s\n", TTF_GetError());
    }
}


void afficher_txt(SDL_Surface *screen,text txt)
{
        SDL_BlitSurface(txt.txt , NULL , screen, &txt.pos);
}



void liberer_button(boutton * btn)
{
SDL_FreeSurface(btn->img[0]);
SDL_FreeSurface(btn->img[1]);

}
void liberer_back(background * back)
{
for(int i=0;i<back->nbr;i++)
SDL_FreeSurface(back->img[i]);
}
void liberer_texte(text *t)
{
SDL_FreeSurface(t->txt);
TTF_CloseFont(t->police);

}
