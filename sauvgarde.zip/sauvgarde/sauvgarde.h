#ifndef SAUVGARDE_H
#define SAUVGARDE_H
//#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
typedef struct
{
SDL_Surface *img[2];
SDL_Rect pos;
int p;
}boutton;
typedef struct
{
SDL_Rect pos1;
SDL_Rect pos2;
SDL_Surface *img[12];
int photo;
int nbr;
}background;
typedef struct
{
    SDL_Rect pos;
    TTF_Font *police;
    SDL_Surface *txt;
    SDL_Color color;
    char nom[256];  // Added to store the text string
}text;


void initialiser_oui(boutton *oui);
void initialiser_non(boutton *non);
void afficher_btn(SDL_Surface *screen,boutton btn);
void afficher_back(SDL_Surface *screen,background b);
void initialiser_textMenu(text *t);
void afficher_txt(SDL_Surface *screen,text txt);
void liberer_button(boutton * btn);
void liberer_back(background * back);
void liberer_texte(text *t);
void initialiser_backmenu(background *back);
void initialiser_textMenu2(text *t);
void initialiser_nouvel(boutton *nouvel);
void initialiser_charger(boutton *charger);
#endif
