#include "sauvgarde.h"
int main()
{
    /*****DECLARATION DES VARIABLES*****/
    
    // Etat du menu
    int menu = 1;
    int sauv = 0;

    // Fenetre
    SDL_Surface* screen;

    // Variables de boucle
    int boucle = 1;

    // Variables d'événements
    SDL_Event event;

    // Background
    background back_menu;

    // Boutons
    boutton oui, non,charger,nouvel;

    // Son
    Mix_Music *musique;
    Mix_Chunk *song_bref;
   
    // Text
    text txt_menu;
    text txt_sauv;

    /*****INITIALISATION DES VARIABLES*****/
    
    TTF_Init();
    screen = SDL_SetVideoMode(1600, 1200, 32, SDL_HWSURFACE | SDL_SRCALPHA);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024);

    // Menu
    initialiser_textMenu(&txt_menu);
    initialiser_textMenu2(&txt_sauv);
    initialiser_backmenu(&back_menu);
    initialiser_oui(&oui);  // Corrected function call
    initialiser_non(&non);  // Corrected function call
    initialiser_charger(&charger);
    initialiser_nouvel(&nouvel);


    musique = Mix_LoadMUS("son/music audio.mp3");
    Mix_PlayMusic(musique, -1);
    song_bref = Mix_LoadWAV("son/pop-window-click-menu-info-35.wav");

    /*****BOUCLE DU JEU*****/
    while (boucle == 1)
    {
        if (menu == 1)
        {
            // Affichage des éléments du menu
            afficher_back(screen, back_menu);
            afficher_btn(screen, oui);
            afficher_btn(screen, non);
            afficher_txt(screen, txt_menu);
        }
        else if(sauv==1){
            afficher_back(screen, back_menu);
            afficher_btn(screen, charger);
            afficher_btn(screen, nouvel);
            afficher_txt(screen, txt_sauv);
         }

        SDL_Flip(screen);

        /****LECTURE DES EVENEMENTS****/
        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
                case SDL_QUIT:
                    boucle = 0;
                    break;
                
                case SDL_MOUSEMOTION:
                    if (menu == 1)
                    {
                        if (event.motion.x > oui.pos.x && event.motion.x < oui.pos.x + oui.pos.w
                            && event.motion.y > oui.pos.y && event.motion.y < oui.pos.y + oui.pos.h)
                        {
                            oui.p = 1;  // Corrected assignment
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else if (event.motion.x > non.pos.x && event.motion.x < non.pos.x + non.pos.w
                            && event.motion.y > non.pos.y && event.motion.y < non.pos.y + non.pos.h)
                        {
                            non.p = 1;  // Corrected assignment
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else
                        {
                            oui.p = 0;  // Corrected assignment
                            non.p = 0;  // Corrected assignment
                        }
                    }
                    else if (sauv == 1)
                    {
                        if (event.motion.x > charger.pos.x && event.motion.x < charger.pos.x + charger.pos.w
                            && event.motion.y > charger.pos.y && event.motion.y < charger.pos.y + charger.pos.h)
                        {
                            charger.p = 1;  // Corrected assignment
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else if (event.motion.x > nouvel.pos.x && event.motion.x < nouvel.pos.x + nouvel.pos.w
                            && event.motion.y > nouvel.pos.y && event.motion.y < nouvel.pos.y + nouvel.pos.h)
                        {
                            nouvel.p = 1;  // Corrected assignment
                            Mix_PlayChannel(-1, song_bref, 0);
                        }
                        else
                        {
                            charger.p = 0;  // Corrected assignment
                            charger.p = 0;  // Corrected assignment
                        }
                    }
                    break;
                
                case SDL_MOUSEBUTTONUP:
                    if (menu==1){
                        if(event.motion.x > oui.pos.x && event.motion.x < oui.pos.x + oui.pos.w
                            && event.motion.y > oui.pos.y && event.motion.y < oui.pos.y + oui.pos.h){
                             menu=0;
                             sauv=1;
                          }
                   
                        
                    }
              

                    break;

                default:
                    break;
            }
        }

      

        SDL_Delay(200);  // Add a small delay to reduce CPU usage
    }

    /*****LIBERATION DES RESSOURCES*****/
    liberer_button(&oui);
    liberer_button(&non);
    liberer_back(&back_menu);
    liberer_texte(&txt_menu);
    Mix_FreeMusic(musique);
    Mix_FreeChunk(song_bref);
    TTF_Quit();

    // Quit SDL subsystems
    SDL_Quit();
    return 0;
}
