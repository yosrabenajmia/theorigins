#ifndef SAVE_H
#define SAVE_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct {
    SDL_Surface *TabTag[10];
    SDL_Rect TabPos[10];
} Background;

typedef struct {
    SDL_Surface *TabBouton[40];
    SDL_Rect TabPos[40];
} Boutton;

// Prototypes des fonctions
void chargerPolice(TTF_Font **font);
void chargerTexte(TTF_Font *font, SDL_Surface **textSurface);
//declaration fonction initialisation son
void chargerSon(Mix_Chunk **hoverSound);
//declaration fonction affichage texte
void afficherTexte(SDL_Surface *textSurface, SDL_Surface *ecran);

void chargerTexte1(TTF_Font *font, SDL_Surface **textSurface) ;
void afficherTexte1(SDL_Surface *textSurface, SDL_Surface *ecran) ;

void chargerBackground(Background *bg);
void afficherBackground(Background *bg, SDL_Surface *ecran);
//declarations des fonctions d'affichage(niveau 6)
void afficherBoutonsreturn(Boutton *button, SDL_Surface *ecran) ;
void afficherBoutonsquit(Boutton *button, SDL_Surface *ecran) ;
void afficherBoutonsstar(Boutton *button, SDL_Surface *ecran) ;
void affichernewBoutonsreturn(Boutton *newButton, SDL_Surface *ecran) ;
void affichernewBoutonsquit(Boutton *newButton, SDL_Surface *ecran) ;

void afficherBoutonsvalid(Boutton *button, SDL_Surface *ecran) ;
void affichernewBoutonsvalid(Boutton *newButton, SDL_Surface *ecran) ;



void chargerBoutons6(Boutton *buttons,Boutton *newbuttons) ;
void chargerBoutons7(Boutton *buttons,Boutton *newbuttons) ;


//liberation
void freeAllButtons(Boutton *buttons, Boutton *newButtons) ;
void cleanup(Mix_Music *music, Mix_Chunk *hoverSound) ;
void libererTexte(SDL_Surface *texteSurface, TTF_Font *font) ;
void libererBackground(Background *bg) ;
#endif // SAVE_H

