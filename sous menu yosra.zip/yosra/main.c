#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "save.h"

int main() {
    SDL_Surface *ecran = NULL;
    SDL_Event event;
    int running = 1;
    TTF_Font *font = NULL;

    Mix_Music *Music = NULL;
    Mix_Chunk *hoverSound = NULL;
    int hoverState[2] = {0};

    Boutton button6,button7;
    Boutton newbutton6,newbutton7;

    Background bg;
    SDL_Surface *textSurface = NULL;
    SDL_Surface *textSurface1 = NULL;


    // Initialisation SDL
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        printf("Erreur SDL : %s\n", SDL_GetError());
        return 1;
    }

    // Initialisation SDL_mixer
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) < 0) {
        printf("Erreur initialisation audio : %s\n", Mix_GetError());
        return 1;
    }

    // Initialisation SDL_ttf
    if (TTF_Init() == -1) {
        printf("Erreur initialisation SDL_ttf : %s\n", TTF_GetError());
        return 1;
    }

    // Chargement de la musique
    Music = Mix_LoadMUS("song.mp3");
    if (Music == NULL) {
        printf("Erreur chargement musique : %s\n", Mix_GetError());
        return 1;
    }


    // Création de la fenêtre
    ecran = SDL_SetVideoMode(1280, 800, 32, SDL_SWSURFACE | SDL_DOUBLEBUF);
    if (ecran == NULL) {
        printf("Erreur création fenêtre : %s\n", SDL_GetError());
        return 1;
    }

    // Chargement des ressources
    //initialisation background
    chargerBackground(&bg);
    //initialisation bouton niveau 
    chargerBoutons6(&button6,&newbutton6) ;
    chargerBoutons7(&button7,&newbutton7) ;
    //initialisation texte+font
    chargerPolice(&font);
    chargerTexte(font, &textSurface);
    chargerTexte1(font, &textSurface1);
    //initialisation son
    chargerSon(&hoverSound);
			
//niv 6/7-------------------
int quit6=0, return6=0;
int valid7=0;

int niveau=7;
    // Boucle d'événements
    while (running) {
	switch(niveau){
		case 1:
			afficherBackground(&bg, ecran);
			Mix_PlayMusic(Music, -1);
			break;
		case 6:
			afficherBackground(&bg, ecran);
			afficherBoutonsstar(&button6, ecran) ;
			afficherTexte(textSurface, ecran);
			if (quit6==0)afficherBoutonsquit(&button6,ecran) ;
			if (quit6==1)affichernewBoutonsquit(&newbutton6,ecran) ;
			if (return6==0)afficherBoutonsreturn(&button6, ecran) ;
			if (return6==1)affichernewBoutonsreturn(&newbutton6, ecran) ;
			break;
		case 7:
			afficherBackground(&bg, ecran);
			afficherTexte1(textSurface1, ecran);
			if (valid7==0)afficherBoutonsvalid(&button7,ecran) ;
			if (valid7==1)affichernewBoutonsvalid(&newbutton7,ecran) ;
			
			break;

        
	}
	SDL_Flip(ecran);
        SDL_PollEvent(&event);
        switch (event.type) {
            case SDL_QUIT:
                running = 0;
                break;
            case SDL_MOUSEMOTION:

// niv 6-------------------------------------------------------------------

		if (event.motion.x >= button6.TabPos[1].x && event.motion.x <= button6.TabPos[1].x + button6.TabPos[1].w &&
                event.motion.y >= button6.TabPos[1].y && event.motion.y <= button6.TabPos[1].y + button6.TabPos[1].h) {
                quit6 = 1;  
		Mix_PlayChannel(-1, hoverSound, 0); 
            } else {
                quit6 = 0;
            }

		if (event.motion.x >= button6.TabPos[0].x && event.motion.x <= button6.TabPos[0].x + button6.TabPos[0].w &&
                event.motion.y >= button6.TabPos[0].y && event.motion.y <= button6.TabPos[0].y + button6.TabPos[0].h) {
                return6 = 1;  
		Mix_PlayChannel(-1, hoverSound, 0); 
            } else {
                return6 = 0;
            }

// niv 7-------------------------------------------------------------------
		
		if (event.motion.x >= button7.TabPos[0].x && event.motion.x <= button7.TabPos[0].x + button7.TabPos[0].w &&
                event.motion.y >= button7.TabPos[0].y && event.motion.y <= button7.TabPos[0].y + button7.TabPos[0].h) {
                valid7 = 1;  
		Mix_PlayChannel(-1, hoverSound, 0); 
            } else {
                valid7 = 0;
            }

            break;


	case SDL_MOUSEBUTTONDOWN:{
            if (event.button.button == SDL_BUTTON_LEFT) {
		switch (niveau){
		    case 6:
			if (event.motion.x >= button6.TabPos[1].x && event.motion.x <= button6.TabPos[1].x + button6.TabPos[1].w &&
		        event.motion.y >= button6.TabPos[1].y && event.motion.y <= button6.TabPos[1].y + button6.TabPos[1].h) {
		        quit6 = 1;
			Mix_PlayChannel(-1, hoverSound, 0);   
			running=0;
		    } 
			if (event.motion.x >= button6.TabPos[0].x && event.motion.x <= button6.TabPos[0].x + button6.TabPos[0].w &&
		        event.motion.y >= button6.TabPos[0].y && event.motion.y <= button6.TabPos[0].y + button6.TabPos[0].h) {
		        return6 = 1;
			Mix_PlayChannel(-1, hoverSound, 0); 
			niveau=1;  
		    } 
			break;
	// niv 7-------------------------------------------------------------------
		    case 7:
			if (event.motion.x >= button7.TabPos[0].x && event.motion.x <= button7.TabPos[0].x + button7.TabPos[0].w &&
		        event.motion.y >= button7.TabPos[0].y && event.motion.y <= button7.TabPos[0].y + button7.TabPos[0].h) {
		        valid7 = 1;
	  		niveau=6;
		   }
			break;
                
	}
		}
            break;

        

            

        default:
            break;
    }


}
}

    freeAllButtons(&button6, &newbutton6);
    freeAllButtons(&button7, &newbutton7);
    libererTexte(textSurface, font) ;
    cleanup(Music, hoverSound);
    libererBackground(&bg) ;
    SDL_FreeSurface(ecran);  
    SDL_Quit();
    return 0;
}








                

