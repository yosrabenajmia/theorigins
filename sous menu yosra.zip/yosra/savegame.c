#include <stdio.h>
#include <stdlib.h>
#include "save.h"

SDL_Surface* resizeimage(SDL_Surface* src, int new_width, int new_height) {
    if (!src) {
        printf("Erreur : Image source NULL\n");
        return NULL;
    }

    SDL_Surface* resized = SDL_CreateRGBSurface(SDL_SWSURFACE, new_width, new_height,
                                                src->format->BitsPerPixel,
                                                src->format->Rmask,
                                                src->format->Gmask,
                                                src->format->Bmask,
                                                src->format->Amask);
    if (!resized) {
        printf("Erreur redimensionnement image : %s\n", SDL_GetError());
        return NULL;
    }

    SDL_Rect src_rec = {0, 0, src->w, src->h};
    SDL_Rect dst_rect = {0, 0, new_width, new_height};
    SDL_SoftStretch(src, &src_rec, resized, &dst_rect);

    SDL_FreeSurface(src); // Éviter les fuites de mémoire
    return resized;
}


void chargerBackground(Background *bg) {
    bg->TabTag[0] = IMG_Load("backrgound3.jpg");
    if (bg->TabTag[0] == NULL) {
        printf("Erreur chargement background : %s\n", IMG_GetError());
        exit(1);
    }
    bg->TabPos[0].x = 0;
    bg->TabPos[0].y = 0;
    bg->TabPos[0].w = bg->TabTag[0]->w;
    bg->TabPos[0].h = bg->TabTag[0]->h;
    bg->TabTag[0] = resizeimage(bg->TabTag[0], 1280, 800); 
}
// initialisation bouton niveau6
void chargerBoutons6(Boutton *buttons,Boutton *newbuttons) 
{
    //boutton niveau6
    buttons->TabBouton[0] = IMG_Load("boutton/niveau6/Return.png");
    buttons->TabBouton[1] = IMG_Load("boutton/niveau6/Quit.png");
    buttons->TabBouton[2] = IMG_Load("boutton/niveau6/stars.png");
    newbuttons->TabBouton[0] = IMG_Load("boutton/niveau6/Returnwhite.png");
    newbuttons->TabBouton[1] = IMG_Load("boutton/niveau6/Quitwhite.png");
    newbuttons->TabBouton[2] = IMG_Load("boutton/niveau6/stars.png");

    // Vérifier si les images sont bien chargées
    for (int i = 0; i < 3; i++) {
        if (buttons->TabBouton[i] == NULL) {
            printf("Erreur chargement boutons : %s\n", IMG_GetError());
        }
        if (newbuttons->TabBouton[i] == NULL) {
            printf("Erreur chargement boutons : %s\n", IMG_GetError());
        }
    }

    // Redimensionner les boutons
    for (int i = 0; i < 2; i++) {
        buttons->TabBouton[i] = resizeimage(buttons->TabBouton[i], 200, 100); 
        newbuttons->TabBouton[i] = resizeimage(newbuttons->TabBouton[i], 200, 100); 
    }
    // Mettre à jour la largeur et la hauteur des boutons
    for (int i = 0; i < 3; i++) {
        buttons->TabPos[i].w = buttons->TabBouton[i]->w;
        buttons->TabPos[i].h = buttons->TabBouton[i]->h;
        newbuttons->TabPos[i].w = newbuttons->TabBouton[i]->w;
        newbuttons->TabPos[i].h = newbuttons->TabBouton[i]->h;
    }


// pos buttons niveau 6
    buttons->TabPos[0].x = 1030; buttons->TabPos[0].y = 650;
    buttons->TabPos[1].x = 800;buttons->TabPos[1].y = 650;
    buttons->TabPos[2].x = 400;buttons->TabPos[2].y =200;
    newbuttons->TabPos[0].x = 1030;newbuttons->TabPos[0].y = 650;
    newbuttons->TabPos[1].x = 800;newbuttons->TabPos[1].y = 650;
    newbuttons->TabPos[2].x = 450;buttons->TabPos[2].y = 200;
}

// initialisation bouton niveau7
void chargerBoutons7(Boutton *buttons,Boutton *newbuttons) 
{
    //boutton niveau7
    buttons->TabBouton[0] = IMG_Load("boutton/niveau7/Validate.png");
    newbuttons->TabBouton[0] = IMG_Load("boutton/niveau7/Validatewhite.png");


    // Vérifier si les images sont bien chargées
    for (int i = 0; i < 1; i++) {
        if (buttons->TabBouton[i] == NULL) {
            printf("Erreur chargement boutons : %s\n", IMG_GetError());
        }
        if (newbuttons->TabBouton[i] == NULL) {
            printf("Erreur chargement boutons : %s\n", IMG_GetError());
        }
    }

    // Redimensionner les boutons
    for (int i = 0; i < 1; i++) {
        buttons->TabBouton[i] = resizeimage(buttons->TabBouton[i], 200, 100); 
        newbuttons->TabBouton[i] = resizeimage(newbuttons->TabBouton[i], 200, 100); 
    }
    // Mettre à jour la largeur et la hauteur des boutons
    for (int i = 0; i < 1; i++) {
        buttons->TabPos[i].w = buttons->TabBouton[i]->w;
        buttons->TabPos[i].h = buttons->TabBouton[i]->h;
        newbuttons->TabPos[i].w = newbuttons->TabBouton[i]->w;
        newbuttons->TabPos[i].h = newbuttons->TabBouton[i]->h;
    }


// pos buttons niveau 7
    buttons->TabPos[0].x = 515; buttons->TabPos[0].y = 650;
    newbuttons->TabPos[0].x = 515;newbuttons->TabPos[0].y = 650;
    
}
// initialisation font
void chargerPolice(TTF_Font **font) {
    *font = TTF_OpenFont("airstrike.ttf", 75);
    if (*font == NULL) {
        printf("Erreur chargement police : %s\n", TTF_GetError());
        exit(1);
    }
}


// initialisation texte
void chargerTexte(TTF_Font *font, SDL_Surface **textSurface) {
    SDL_Color color = {255, 255, 255};  // Blanc
    *textSurface = TTF_RenderText_Solid(font, "BEST SCORES", color);
    if (*textSurface == NULL) {
        printf("Erreur création surface texte : %s\n", TTF_GetError());
        exit(1);
    }
}


// charger son 
void chargerSon(Mix_Chunk **hoverSound) {
    *hoverSound = Mix_LoadWAV("hover.wav");
    if (*hoverSound == NULL) {
        printf("Erreur chargement son : %s\n", Mix_GetError());
        exit(1);
    }
}

void afficherTexte(SDL_Surface *textSurface, SDL_Surface *ecran) {
    SDL_Rect pos;
    pos.x = 375;  // Position X du texte
    pos.y = 180;  // Position Y du texte

    SDL_BlitSurface(textSurface, NULL, ecran, &pos);
}

void chargerTexte1(TTF_Font *font, SDL_Surface **textSurface) {
    SDL_Color color = {255, 255, 255};  // Blanc
    *textSurface = TTF_RenderText_Solid(font, "enter your name", color);
    if (*textSurface == NULL) {
        printf("Erreur création surface texte : %s\n", TTF_GetError());
        exit(1);
    }
}

void afficherTexte1(SDL_Surface *textSurface, SDL_Surface *ecran) {
    SDL_Rect pos;
    pos.x = 280;  // Position X du texte
    pos.y = 200;  // Position Y du texte

    SDL_BlitSurface(textSurface, NULL, ecran, &pos);
}

void afficherBackground(Background *bg, SDL_Surface *ecran) {
    SDL_BlitSurface(bg->TabTag[0], NULL, ecran, &bg->TabPos[0]);
}


//boutons niv6-----------------------------------------------------------

void afficherBoutonsreturn(Boutton *button, SDL_Surface *ecran) {
   
        SDL_BlitSurface(button->TabBouton[0], NULL, ecran, &button->TabPos[0]);
    }

void afficherBoutonsquit(Boutton *button, SDL_Surface *ecran) {
   
        SDL_BlitSurface(button->TabBouton[1], NULL, ecran, &button->TabPos[1]);
    }
//-------------------------------------------stars---------------------------
void afficherBoutonsstar(Boutton *button, SDL_Surface *ecran) {
   
        SDL_BlitSurface(button->TabBouton[2], NULL, ecran, &button->TabPos[2]);
    }
//---------------------------------------------------------------------------
void affichernewBoutonsreturn(Boutton *newButton, SDL_Surface *ecran) {
   
        SDL_BlitSurface(newButton->TabBouton[0], NULL, ecran, &newButton->TabPos[0]);
    }

void affichernewBoutonsquit(Boutton *newButton, SDL_Surface *ecran) {
   
        SDL_BlitSurface(newButton->TabBouton[1], NULL, ecran, &newButton->TabPos[1]);
    }


// affiche niv 7 ---------------------------



void afficherBoutonsvalid(Boutton *button, SDL_Surface *ecran) {
   
        SDL_BlitSurface(button->TabBouton[0], NULL, ecran, &button->TabPos[0]);
    }



void affichernewBoutonsvalid(Boutton *newButton, SDL_Surface *ecran) {
   
        SDL_BlitSurface(newButton->TabBouton[0], NULL, ecran, &newButton->TabPos[0]);
    }



void freeAllButtons(Boutton *buttons, Boutton *newButtons) {
    // Libération de la mémoire des boutons pour le niveau 4
    for (int i = 0; i < 40; i++) {
        if (buttons->TabBouton[i]) {
            SDL_FreeSurface(buttons->TabBouton[i]);
        }
        if (newButtons->TabBouton[i]) {
            SDL_FreeSurface(newButtons->TabBouton[i]);
        }
    }
}



void cleanup(Mix_Music *music, Mix_Chunk *hoverSound) {
    // Libération des ressources audio
    if (music != NULL) {
        Mix_FreeMusic(music);
    }
    if (hoverSound != NULL) {
        Mix_FreeChunk(hoverSound);
    }
    Mix_CloseAudio();
}


void libererTexte(SDL_Surface *texteSurface, TTF_Font *font) {
    // Libère la surface contenant le texte
    if (texteSurface != NULL) {
        SDL_FreeSurface(texteSurface);
        texteSurface = NULL;  
    }

    // Libère la police (font)
    if (font != NULL) {
        TTF_CloseFont(font);
        font = NULL;  
    }
}

void libererBackground(Background *bg) {
    // Libérer toutes les surfaces de fond dans TabTag
    for (int i = 0; i < 10; i++) {
        if (bg->TabTag[i] != NULL) {
            SDL_FreeSurface(bg->TabTag[i]);  // Libère la surface
            bg->TabTag[i] = NULL;  // Evite un accès futur à la surface libérée
        }
    }
}



