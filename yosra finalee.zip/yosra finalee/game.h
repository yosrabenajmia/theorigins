#ifndef GAME_H
#define GAME_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>           // <-- for text

void initPuzzle();
int handlePuzzle(SDL_Surface *screen, Mix_Chunk *clickSound);
void cleanPuzzle();
void showRotoZoom(SDL_Surface *screen, const char *imagePath);

void startTimer();
int isTimeUp();
void drawTimer(SDL_Surface *screen);

#endif
