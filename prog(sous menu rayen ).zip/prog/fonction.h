#ifndef FONCTION_H
#define FONCTION_H
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>



typedef struct
{
	char *url;
	SDL_Rect pos_img;   //position de l'image par rapport a l'ecran
	SDL_Rect part_img;  //la partie de l'image a afficher
	SDL_Surface *img;
	
	
 

}image;
typedef struct
{
Mix_Music *music;
Mix_Chunk *cmusic;
}audio;


void initialisation_option_button(image *option);
void affichage_option_button(SDL_Surface *screen,image option);
void initialisation_settings_background(image *settingsbackground);
void affichage_settings_background(SDL_Surface *screen,image settingsbackground);
void initialisation_sound_button(image *start_img);
void affichage_sound_button(SDL_Surface *screen,image start_img);
void liberer_image(image imgee);
//initialisation des images de %
void initialisation_background_music(audio *back_music);
void liberer_background_music(audio *back_music);
void initialisation_0_img(image *img0);
void initialisation_25_img(image *img25);
void initialisation_50_img(image *img50);
void initialisation_75_img(image *img75);
void initialisation_100_img(image *img100);

//affichage des images de %
void affichage_0_img(SDL_Surface *screen,image img0);

void affichage_25_img(SDL_Surface *screen,image img25);
void affichage_50_img(SDL_Surface *screen,image img50);
void affichage_75_img(SDL_Surface *screen,image img75);
void affichage_100_img(SDL_Surface *screen,image img100);

//volume modification
void volume_mod(audio *back_music,audio *button_sound,int volumestate);

//on and off fullscreen
void initialisation_onFS(image *onF);
void initialisation_offFS(image *offF);
void affichage_onFS(SDL_Surface *screen,image onF);
void affichage_offFS(SDL_Surface *screen,image offF);

//mute on off
void initialisation_mute_off(image *muteoff);
void initialisation_mute_on(image *muteon);
void affichage_mute_off(SDL_Surface *screen,image muteoff);
void affichage_mute_on(SDL_Surface *screen,image muteon);
void initialisation_button_sound(audio *button_sound);
void liberer_button_sound(audio *button_sound);
void initialisation_back_button(image *back);
void affichage_back_button(SDL_Surface *screen,image back);
void initialisation_updated_back_button(image *back);
void affichage_updated_back_button(SDL_Surface *screen,image back);


#endif
