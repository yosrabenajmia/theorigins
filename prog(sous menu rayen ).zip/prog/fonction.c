#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "fonction.h"
//******************* BACKGROUND MUSIC FUNCTIONS *******************

void initialisation_background_music(audio *back_music)
{
if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)
{
printf("unable to play background music %s \n",SDL_GetError());
}
back_music->music=Mix_LoadMUS("sound background.mp3");
Mix_PlayMusic(back_music->music,-1);
Mix_VolumeMusic(MIX_MAX_VOLUME*0.2);
}



void liberer_background_music(audio *back_music)
{
Mix_FreeMusic(back_music->music);
}
void initialisation_sound_button(image *start_img)
{
start_img->url="sound.png";
start_img->img=IMG_Load(start_img->url);
if(start_img->img==NULL)
{
printf("unable to load start image %s \n",SDL_GetError());
return;
}
start_img->pos_img.x=0;
start_img->pos_img.y=0;
start_img->pos_img.w=341;
start_img->pos_img.h=115;
start_img->part_img.x=145;
start_img->part_img.y=350;

}


void affichage_sound_button(SDL_Surface *screen,image start_img)
{
SDL_BlitSurface(start_img.img,NULL,screen,&start_img.part_img);   

}
//******************* SETTINGS BACKGROUND IMAGE FUNCTIONS *******************
void initialisation_settings_background(image *settingsbackground)
{
settingsbackground->url="background 1.png";
settingsbackground->img=IMG_Load(settingsbackground->url);
if(settingsbackground->img==NULL)
{
printf("unable to load settings background image %s \n",SDL_GetError());
return;
}


}
void affichage_settings_background(SDL_Surface *screen,image settingsbackground)
{

SDL_BlitSurface(settingsbackground.img,NULL,screen,NULL);  //&settingsbackground.part_img

}
void liberer_image(image imgee)
{
SDL_FreeSurface(imgee.img);

}

//******************* 0% FUNCTIONS *******************
void initialisation_0_img(image *img0)
{
img0->url="0.png";
img0->img=IMG_Load(img0->url);
if(img0->img==NULL)
{
printf("unable to load 0 image %s \n",SDL_GetError());
return;
}
img0->pos_img.x=115;  
img0->pos_img.y=490;  
img0->pos_img.w=410;
img0->pos_img.h=40;



}

void affichage_0_img(SDL_Surface *screen,image img0)
{
SDL_BlitSurface(img0.img,NULL,screen,&img0.pos_img);
}





//******************* 25% FUNCTIONS *******************
void initialisation_25_img(image *img25)
{
img25->url="25.png";
img25->img=IMG_Load(img25->url);
if(img25->img==NULL)
{
printf("unable to load 25 image %s \n",SDL_GetError());
return;
}
img25->pos_img.x=115;
img25->pos_img.y=490;
img25->pos_img.w=410;
img25->pos_img.h=40;



}

void affichage_25_img(SDL_Surface *screen,image img25)
{
SDL_BlitSurface(img25.img,NULL,screen,&img25.pos_img);
}


//******************* 50% FUNCTIONS *******************
void initialisation_50_img(image *img50)
{
img50->url="50.png";
img50->img=IMG_Load(img50->url);
if(img50->img==NULL)
{
printf("unable to load 50 image %s \n",SDL_GetError());
return;
}
img50->pos_img.x=115;
img50->pos_img.y=490;
img50->pos_img.w=410;
img50->pos_img.h=40;



}

void affichage_50_img(SDL_Surface *screen,image img50)
{
SDL_BlitSurface(img50.img,NULL,screen,&img50.pos_img);
}


//******************* 75% FUNCTIONS *******************
void initialisation_75_img(image *img75)
{
img75->url="75.png";
img75->img=IMG_Load(img75->url);
if(img75->img==NULL)
{
printf("unable to load 75 image %s \n",SDL_GetError());
return;
}
img75->pos_img.x=115;
img75->pos_img.y=490;
img75->pos_img.w=410;
img75->pos_img.h=40;



}

void affichage_75_img(SDL_Surface *screen,image img75)
{
SDL_BlitSurface(img75.img,NULL,screen,&img75.pos_img);
}



//******************* 100% FUNCTIONS *******************
void initialisation_100_img(image *img100)
{
img100->url="100.png";
img100->img=IMG_Load(img100->url);
if(img100->img==NULL)
{
printf("unable to load 100 image %s \n",SDL_GetError());
return;
}
img100->pos_img.x=115;
img100->pos_img.y=490;
img100->pos_img.w=410;
img100->pos_img.h=40;



}

void affichage_100_img(SDL_Surface *screen,image img100)
{
SDL_BlitSurface(img100.img,NULL,screen,&img100.pos_img);
}



//******************* mute on off FUNCTIONS *******************

void initialisation_mute_off(image *muteoff)
{
muteoff->url="off.png";
muteoff->img=IMG_Load(muteoff->url);
if(muteoff->img==NULL)
{
printf("unable to load off image %s \n",SDL_GetError());
return;
}
muteoff->pos_img.x=230;
muteoff->pos_img.y=250;
muteoff->pos_img.w=170;
muteoff->pos_img.h=75;


}
void initialisation_mute_on(image *muteon)
{
muteon->url="on.png";
muteon->img=IMG_Load(muteon->url);
if(muteon->img==NULL)
{
printf("unable to load on image %s \n",SDL_GetError());
return;
}
muteon->pos_img.x=230;
muteon->pos_img.y=250;
muteon->pos_img.w=170;
muteon->pos_img.h=75;

}
void affichage_mute_off(SDL_Surface *screen,image muteoff)
{
SDL_BlitSurface(muteoff.img,NULL,screen,&muteoff.pos_img);
}
void affichage_mute_on(SDL_Surface *screen,image muteon)
{
SDL_BlitSurface(muteon.img,NULL,screen,&muteon.pos_img);
}

//on and off fullscreen
void initialisation_onFS(image *onF)
{
onF->url="on.png";
onF->img=IMG_Load(onF->url);
if(onF->img==NULL)
{
printf("unable to load on image %s \n",SDL_GetError());
return;
}
onF->pos_img.x=230;
onF->pos_img.y=600;
onF->pos_img.w=170;
onF->pos_img.h=75;

}
void initialisation_offFS(image *offF)
{
offF->url="off.png";
offF->img=IMG_Load(offF->url);
if(offF->img==NULL)
{
printf("unable to load off image %s \n",SDL_GetError());
return;
}
offF->pos_img.x=230;
offF->pos_img.y=600;
offF->pos_img.w=170;
offF->pos_img.h=75;
}
void affichage_onFS(SDL_Surface *screen,image onF)
{
SDL_BlitSurface(onF.img,NULL,screen,&onF.pos_img);
}
void affichage_offFS(SDL_Surface *screen,image offF)
{
SDL_BlitSurface(offF.img,NULL,screen,&offF.pos_img);
}
//volume modification function
void volume_mod(audio *back_music,audio *button_sound,int volumestate)
{
float a;
float volumest= (float) volumestate;
a=volumest/5;
Mix_VolumeMusic(MIX_MAX_VOLUME * a);
Mix_VolumeChunk(button_sound->cmusic,MIX_MAX_VOLUME * a);
}
/*****************************options*/
void initialisation_option_button(image *option)
{
option->url="option1.png";
option->img=IMG_Load(option->url);
if(option->img==NULL)
{
printf("unable to load option image %s \n",SDL_GetError());
return;
}
option->pos_img.x=0;
option->pos_img.y=0;
option->pos_img.w=1700;
option->pos_img.h=200;
option->part_img.x=600;
option->part_img.y=40;
}


void affichage_option_button(SDL_Surface *screen,image option)
{
SDL_BlitSurface(option.img,NULL,screen,&option.part_img);   

}
/******************/
//******************* BUTTON SOUND FUNCTIONS *******************
void initialisation_button_sound(audio *button_sound)
{
if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,2048)==-1)
{
printf("unable to play button sound effect %s \n",SDL_GetError());
}
if (!button_sound) {
    fprintf(stderr, "Erreur : pointeur button_sound non initialisé !\n");
    return;
}

button_sound->cmusic=Mix_LoadWAV("mousebuttoon.wav");
if (button_sound->cmusic == NULL) {
    fprintf(stderr, "Erreur : le son n'a pas été chargé correctement !\n");
    return;
}

Mix_PlayChannel(1,button_sound->cmusic,0);
Mix_VolumeChunk(button_sound->cmusic,MIX_MAX_VOLUME*0.2);
}

void liberer_button_sound(audio *button_sound)
{
Mix_FreeChunk(button_sound->cmusic);
}

/***************************/
void initialisation_back_button(image *back)
{
back->url="back2.png";
back->img=IMG_Load(back->url);
if(back->img==NULL)
{
printf("unable to load back image %s \n",SDL_GetError());
return;
}
back->pos_img.x=0;
back->pos_img.y=0;
back->pos_img.w=161;
back->pos_img.h=91;
back->part_img.x=1150;
back->part_img.y=800;

}

void affichage_back_button(SDL_Surface *screen,image back)
{
SDL_BlitSurface(back.img,NULL,screen,&back.part_img);   

}

//******************* UPDATED_back BUTTON IMAGE FUNCTIONS *******************
void initialisation_updated_back_button(image *back)
{
back->url="back1.png";
back->img=IMG_Load(back->url);
if(back->img==NULL)
{
printf("unable to load updated back effect image %s \n",SDL_GetError());
return;
}
back->pos_img.x=0;
back->pos_img.y=0;
back->pos_img.w=161;
back->pos_img.h=91;
back->part_img.x=1150;
back->part_img.y=800;

}

void affichage_updated_back_button(SDL_Surface *screen,image back)
{
SDL_BlitSurface(back.img,NULL,screen,&back.part_img);
}

