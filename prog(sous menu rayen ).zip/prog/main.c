#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "fonction.h"
int main(int argc, char *argv[])
{

 SDL_Surface *screen=NULL;
 image settings_background,sounds,option,back,back1;
SDL_Event event;
 int boucle=1;
int currentScreen=2;
 int settingsstate=0;
 int FSstate=0;
 int mutestate=0;
 int quitstate=0;
int backstate=0;
audio backmusic,buttonsound;
 image img0,img25,img50,img75,img100,onFS,offFS,muteon,muteoff;
 int volumestate=2;


 
  printf("Initialisation SDL...\n");
if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
    printf("Erreur SDL : %s\n", SDL_GetError());
    return 1;
}
printf("SDL initialisée avec succès !\n");
  
  screen=SDL_SetVideoMode(1440,900,32,SDL_SWSURFACE|SDL_DOUBLEBUF);
 SDL_WM_SetCaption("Cyber Cy",NULL);
 initialisation_settings_background(&settings_background);
initialisation_sound_button(&sounds);
 initialisation_background_music(&backmusic);
initialisation_back_button(&back);
initialisation_updated_back_button(&back1);

initialisation_button_sound(&buttonsound);
//initialisation des images de %
  initialisation_0_img(&img0);
  initialisation_25_img(&img25);
  initialisation_50_img(&img50);
  initialisation_75_img(&img75);
  initialisation_100_img(&img100);
  
  //initialisation on and off fullscreen
  initialisation_onFS(&onFS);
  initialisation_offFS(&offFS);
  
  //initialisation on off mute
  initialisation_mute_off(&muteoff);
  initialisation_mute_on(&muteon);
 initialisation_option_button(&option);
 
 SDL_Flip(screen);
while(boucle)
  {
  
      
  affichage_settings_background(screen,settings_background); 
    
         
    	 

    
if (currentScreen == 2)
   	{
          
   	 affichage_50_img(screen,img50);
   
         affichage_settings_background(screen,settings_background); 
         affichage_option_button(screen,option);
         affichage_sound_button(screen,sounds);
    	 affichage_mute_off(screen,muteoff);
	 affichage_offFS(screen,offFS);
	//affichage_offFS(screen,offFS);
  	   if(FSstate==0)
  	    {affichage_offFS(screen,offFS);}
  	    else if (FSstate==1)
  	     {affichage_onFS(screen,onFS);}
  	//affichage on off mute
  	   if(mutestate==0)
  	    {affichage_mute_off(screen,muteoff);
  	    }
  	    if(mutestate==1)
  	     {	 affichage_mute_on(screen,muteon);
  	      }
if(backstate==1)
  {
  affichage_updated_back_button(screen,back1);
  }
  else if(backstate==0)
  {
  affichage_back_button(screen,back);
  }

       }     
  //affichage et changement de volume
  
  
  if (currentScreen == 2 && volumestate==0)
  	{
  	affichage_0_img(screen,img0);
  	volume_mod(&backmusic,&buttonsound,volumestate);
  	}

  if (currentScreen == 2 && volumestate==1)
  	{
  	affichage_25_img(screen,img25);
  	volume_mod(&backmusic,&buttonsound,volumestate);
  	}
  	  	  
  if (currentScreen == 2 && volumestate==2)
  	{
  	affichage_50_img(screen,img50);
  	volume_mod(&backmusic,&buttonsound,volumestate);
  	}  
  
  if (currentScreen == 2 && volumestate==3)
  	{
  	affichage_75_img(screen,img75);
  	volume_mod(&backmusic,&buttonsound,volumestate);
  	}  
  
  if (currentScreen == 2 && volumestate==4)
  	{
  	affichage_100_img(screen,img100);
  	volume_mod(&backmusic,&buttonsound,volumestate);
  	}  
SDL_Flip(screen);
while(SDL_PollEvent(&event)){
  switch(event.type)
  {
  	case SDL_QUIT:
  	boucle=0;
  	break;
       case SDL_MOUSEBUTTONDOWN:
  	if (event.button.button == SDL_BUTTON_LEFT)
  	{ 
  	initialisation_button_sound(&buttonsound);
  	}
        break;

       case SDL_MOUSEBUTTONUP:
if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT && (event.motion.y<=891 && event.motion.y>=800
          && event.motion.x<=1311 && event.button.x>=1150)) {
                    backstate=1;
                        boucle=0;
                }
                

if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT &&(event.button.y<=465 && event.button.y>=350
          						                    && event.button.x<=315 && event.button.x>=145)) {
                    volumestate --;  
                   
                    }  
         //en cas yenzel -
         
         if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT &&(event.button.y<=465 && event.button.y>=350
          						                    && event.button.x<=486 && event.button.x>=315)) {
                    volumestate ++;  
                   
                    }    
  	
  	  	//full screen on 
         if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT &&(event.button.y<=675 && event.button.y>=600
          						                    && event.button.x<=315 && event.button.x>=230)) {
                    FSstate=1;

                    screen=SDL_SetVideoMode(1920, 1200, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
                    
                    
                     
                  
                    }      	
  	//full screen off  "798,249,936,287
         if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT &&(event.button.y<=675 && event.button.y>=600
          						                    && event.button.x<=400 && event.button.x>=315)) {
                    FSstate=0;
                    screen=SDL_SetVideoMode(1440,900,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
                    
                    
                    
                    }  	
        // mute on then off 797,609,934,650
  	if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT &&(event.button.y<=325 && event.button.y>=250
          						                    && event.button.x<=400 && event.button.x>=315)) {
              
                   
                      mutestate=0;
                       volumestate=2;
                    		 
                 Mix_VolumeMusic(volumestate);
                    }
  		 if (currentScreen == 2  && event.button.button==SDL_BUTTON_LEFT &&(event.button.y<=325 && event.button.y>=250
          						                    && event.button.x<=315 && event.button.x>=230)) {
              
                   		 mutestate=1;
                   	volumestate=0;
                  
                    Mix_VolumeMusic(volumestate);
                   		 }

  	
  	break;

case SDL_KEYDOWN:
                if (event.key.keysym.sym == SDLK_ESCAPE)
                {
                    
                    boucle=0;
                }
        
}            		 
}
}
liberer_image(settings_background);

liberer_image(option);
  SDL_Quit();
  
  
  

return 0;
}

