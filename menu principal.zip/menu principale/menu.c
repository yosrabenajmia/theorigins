#include "menu.h"
#include <stdio.h>
#include <SDL/SDL_ttf.h>

void init_menu(Menu *m, SDL_Surface *ecran) {
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        printf("SDL_image does not support PNG: %s\n", IMG_GetError());
        return;
    }

    printf("Loading images...\n");
   
    m->background = IMG_Load("backgroundprincipale.jpg");
    if (!m->background)
        printf("Error loading background: %s\n", IMG_GetError());

    TTF_Font *font = TTF_OpenFont("arial.ttf", 24);
    if (!font) {
        fprintf(stderr, "Failed to load font: %s\n", TTF_GetError());
        m->textSurface = NULL;
    } else {
        SDL_Color textColor = { 0, 0, 0 };
        m->textSurface = TTF_RenderText_Solid(font, "THE ORIGIN", textColor);
        TTF_CloseFont(font);
    }
    m->textPos.x = 0;
    m->textPos.y = 0;

    m->play_btn[0] = IMG_Load("play.png");
    m->play_btn[1] = IMG_Load("play_hover.png");

    m->options_btn[0] = IMG_Load("options.png");
    m->options_btn[1] = IMG_Load("options_hover.png");

    m->best_score_btn[0] = IMG_Load("best_score.png");
    m->best_score_btn[1] = IMG_Load("best_score_hover.png");

    m->history_btn[0] = IMG_Load("history.png");
    m->history_btn[1] = IMG_Load("history_hover.png");

    m->quit_btn[0] = IMG_Load("quit.png");
    m->quit_btn[1] = IMG_Load("quit_hover.png");

    m->logo = IMG_Load("logo.png");
    m->pos_logo.x = 350;
    m->pos_logo.y = 10;

    m->textPos.x = m->pos_logo.x + 300;
    m->textPos.y = m->pos_logo.y+75;

    m->pos_btn_play.x = 20;
    m->pos_btn_play.y = 10;

    m->pos_btn_option.x = 20;
    m->pos_btn_option.y = 150;

    m->pos_btn_best_score.x = 20;
    m->pos_btn_best_score.y = 250;

    m->pos_btn_history.x = 20;
    m->pos_btn_history.y = 350;

    m->pos_btn_quit.x = 20;
    m->pos_btn_quit.y = 450;

    m->hovered_play = 0;
    m->hovered_option = 0;
    m->hovered_best_score = 0;
    m->hovered_history = 0;
    m->hovered_quit = 0;
}

void update_hover_state(SDL_Rect *pos_btn, int *hovered) {
    int x_souris, y_souris;
    SDL_GetMouseState(&x_souris, &y_souris);

    if (x_souris > pos_btn->x && x_souris < (pos_btn->x + pos_btn->w) &&
        y_souris > pos_btn->y && y_souris < (pos_btn->y + pos_btn->h)) {
        *hovered = 1;
    } else {
        *hovered = 0;
    }
}

void afficher_menu(Menu *m, SDL_Surface *ecran) {
    SDL_BlitSurface(m->background, NULL, ecran, NULL);

    update_hover_state(&m->pos_btn_play, &m->hovered_play);
    SDL_BlitSurface(m->hovered_play ? m->play_btn[1] : m->play_btn[0], NULL, ecran, &m->pos_btn_play);

    update_hover_state(&m->pos_btn_option, &m->hovered_option);
    SDL_BlitSurface(m->hovered_option ? m->options_btn[1] : m->options_btn[0], NULL, ecran, &m->pos_btn_option);

    update_hover_state(&m->pos_btn_best_score, &m->hovered_best_score);
    SDL_BlitSurface(m->hovered_best_score ? m->best_score_btn[1] : m->best_score_btn[0], NULL, ecran, &m->pos_btn_best_score);

    update_hover_state(&m->pos_btn_history, &m->hovered_history);
    SDL_BlitSurface(m->hovered_history ? m->history_btn[1] : m->history_btn[0], NULL, ecran, &m->pos_btn_history);

    update_hover_state(&m->pos_btn_quit, &m->hovered_quit);
    SDL_BlitSurface(m->hovered_quit ? m->quit_btn[1] : m->quit_btn[0], NULL, ecran, &m->pos_btn_quit);

    SDL_BlitSurface(m->logo, NULL, ecran, &m->pos_logo);

    if (m->textSurface) {
        SDL_BlitSurface(m->textSurface, NULL, ecran, &m->textPos);
    }
}
	


	

