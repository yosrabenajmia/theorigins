#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <math.h>

int main(int argc, char *argv[]) {
    SDL_Surface *screen = NULL;
    Enigme e;
    bool continuer = true;
    SDL_Event event;
    char niveau[10] = "Enigme";
    srand(time(NULL));
    
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur SDL_Init: %s\n", SDL_GetError());
        return EXIT_FAILURE;
    }

    if (TTF_Init() == -1) {
        printf("Erreur TTF_Init: %s\n", TTF_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        printf("Erreur IMG_Init: %s\n", IMG_GetError());
        TTF_Quit();
        SDL_Quit();
        return EXIT_FAILURE;
    }

    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (!screen) {
        printf("Erreur création fenêtre: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return EXIT_FAILURE;
    }

    SDL_WM_SetCaption("Jeu d'Enigmes", NULL);
    initEnigme(&e);
    genererEnigme(&e, "enigmes.txt");

    while (continuer) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                continuer = false;
            }
            else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                if (strcmp(niveau, "Enigme") == 0 && e.etat == 0) {
                    int x = event.button.x;
                    int y = event.button.y;
                    if (e.reponse1 && x >= e.pos_reponse1.x && x <= e.pos_reponse1.x + e.reponse1->w &&
                        y >= e.pos_reponse1.y && y <= e.pos_reponse1.y + e.reponse1->h) {
                        verifierReponse(&e, 1);
                    } 
                    else if (e.reponse2 && x >= e.pos_reponse2.x && x <= e.pos_reponse2.x + e.reponse2->w &&
                             y >= e.pos_reponse2.y && y <= e.pos_reponse2.y + e.reponse2->h) {
                        verifierReponse(&e, 2);
                    } 
                    else if (e.reponse3 && x >= e.pos_reponse3.x && x <= e.pos_reponse3.x + e.reponse3->w &&
                             y >= e.pos_reponse3.y && y <= e.pos_reponse3.y + e.reponse3->h) {
                        verifierReponse(&e, 3);
                    }
                }
            }
        }

        if (strcmp(niveau, "Enigme") == 0 && e.etat == 0) {
            Uint32 maintenant = SDL_GetTicks();
            e.tempsRestant = 30 - ((maintenant - e.debutTemps) / 1000);
            if (e.tempsRestant <= 0) {
                verifierReponse(&e, -1);
            }
        }

        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
        if (e.background) {
            SDL_BlitSurface(e.background, NULL, screen, NULL);
        }

        if (strcmp(niveau, "Enigme") == 0) {
            if (e.etat == 0) {
                // Draw arc timer behind logo
                if (e.tempsRestant > 0) {
                    Uint32 timerColor;
                    if (e.tempsRestant > 20) timerColor = SDL_MapRGB(screen->format, 0, 255, 0);
                    else if (e.tempsRestant > 10) timerColor = SDL_MapRGB(screen->format, 255, 255, 0);
                    else timerColor = SDL_MapRGB(screen->format, 255, 0, 0);

                    // Position behind logo (65px, 90px)
                    const int centerX = 65;
                    const int centerY = 90;
                    const int radius = 30;
                    const double thickness = 4.0;
                    const double startAngle = M_PI;
                    const double endAngle = startAngle - ((30 - e.tempsRestant) * (M_PI / 15));

                    // Draw thick arc using small rectangles
                    for (double angle = startAngle; angle >= endAngle; angle -= 0.02) {
                        for (double t = 0; t < thickness; t += 0.5) {
                            int x = centerX + (int)((radius - t) * cos(angle));
                            int y = centerY + (int)((radius - t) * sin(angle));
                            SDL_Rect pixel = {x, y, 2, 2};
                            SDL_FillRect(screen, &pixel, timerColor);
                        }
                    }
                }

                // Draw UI elements
                if (e.question) SDL_BlitSurface(e.question, NULL, screen, &e.pos_question);
                if (e.reponse1) SDL_BlitSurface(e.reponse1, NULL, screen, &e.pos_reponse1);
                if (e.reponse2) SDL_BlitSurface(e.reponse2, NULL, screen, &e.pos_reponse2);
                if (e.reponse3) SDL_BlitSurface(e.reponse3, NULL, screen, &e.pos_reponse3);
            } else {
                SDL_Color color;
                const char* msg;
                
                if (e.etat == 1) {
                    color = (SDL_Color){0, 255, 0, 255};
                    msg = "Bonne reponse !";
                } 
                else if (e.etat == -2) {
                    color = (SDL_Color){255, 0, 0, 255};
                    msg = "Temps ecoule !";
                } 
                else {
                    color = (SDL_Color){255, 0, 0, 255};
                    msg = "Mauvaise reponse !";
                }

                SDL_Surface* text = TTF_RenderText_Blended(e.font, msg, color);
                if (text) {
                    SDL_Rect pos = {SCREEN_WIDTH/2 - text->w/2, SCREEN_HEIGHT/2 - text->h/2, 0, 0};
                    SDL_BlitSurface(text, NULL, screen, &pos);
                    SDL_FreeSurface(text);
                }
                
                SDL_Flip(screen);
                SDL_Delay(2000);
                libererEnigme(&e);
                genererEnigme(&e, "enigmes.txt");
            }
        }

        SDL_Flip(screen);
    }

    libererEnigme(&e);
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
    return EXIT_SUCCESS;
}
