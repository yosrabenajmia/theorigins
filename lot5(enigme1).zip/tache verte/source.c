#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void initEnigme(Enigme *e) {
    e->question = e->reponse1 = e->reponse2 = e->reponse3 = NULL;
    e->background = NULL;
    e->textColor = (SDL_Color){0, 0, 0, 255};
    e->font = TTF_OpenFont("fonts/arial.ttf", 20);
    if (!e->font) {
        e->font = TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSans.ttf", 20);
    }
    if (e->font) {
        TTF_SetFontStyle(e->font, TTF_STYLE_BOLD);
    } else {
        printf("Erreur chargement police\n");
        exit(EXIT_FAILURE);
    }
    e->etat = 0;
    e->bonneReponse = 0;
    e->questionsUtilisees = NULL;
    e->totalQuestions = 0;
    e->tempsRestant = 30;
    e->background = IMG_Load("background tache verte.png");
    if (!e->background) {
        e->background = SDL_CreateRGBSurface(SDL_HWSURFACE, SCREEN_WIDTH, SCREEN_HEIGHT, 32, 0, 0, 0, 0);
        SDL_FillRect(e->background, NULL, SDL_MapRGB(e->background->format, 0, 0, 128));
    }
}

void decomposer(char *chaine, Enigme *e) {
    chaine[strcspn(chaine, "\n")] = 0;
    char *token = strtok(chaine, ";");
    
    if (token) e->question = TTF_RenderText_Blended(e->font, token, e->textColor);
    token = strtok(NULL, ";");
    if (token) e->reponse1 = TTF_RenderText_Blended(e->font, token, e->textColor);
    token = strtok(NULL, ";");
    if (token) e->reponse2 = TTF_RenderText_Blended(e->font, token, e->textColor);
    token = strtok(NULL, ";");
    if (token) e->reponse3 = TTF_RenderText_Blended(e->font, token, e->textColor);
    token = strtok(NULL, ";");
    if (token) e->bonneReponse = atoi(token);
}

void genererEnigme(Enigme *e, const char *nomfich) {
    FILE *f = fopen(nomfich, "r");
    if (!f) {
        printf("Erreur ouverture fichier\n");
        exit(EXIT_FAILURE);
    }

    char lignes[20][256];
    int count = 0;
    while (fgets(lignes[count], sizeof(lignes[count]), f) && count < 20) {
        count++;
    }
    fclose(f);

    if (!e->questionsUtilisees) {
        e->totalQuestions = count;
        e->questionsUtilisees = calloc(count, sizeof(int));
    }

    int index;
    do {
        index = rand() % count;
    } while (e->questionsUtilisees[index] == 1 && count > 0);

    if (count > 0) {
        e->questionsUtilisees[index] = 1;
        decomposer(lignes[index], e);
    }
    e->pos_question.x = 600; e->pos_question.y = 400;
    e->pos_reponse1.x = 600; e->pos_reponse1.y = 500;
    e->pos_reponse2.x = 600; e->pos_reponse2.y = 600;
    e->pos_reponse3.x = 600; e->pos_reponse3.y = 700;
    e->debutTemps = SDL_GetTicks();
    e->tempsRestant = 30;
    e->etat = 0;
}

void libererEnigme(Enigme *e) {
    if (e->question) SDL_FreeSurface(e->question);
    if (e->reponse1) SDL_FreeSurface(e->reponse1);
    if (e->reponse2) SDL_FreeSurface(e->reponse2);
    if (e->reponse3) SDL_FreeSurface(e->reponse3);
    if (e->font) TTF_CloseFont(e->font);
    if (e->background) SDL_FreeSurface(e->background);
    if (e->questionsUtilisees) free(e->questionsUtilisees);
}

int verifierReponse(Enigme *e, int choix) {
    if (choix == -1) { 
        e->etat = -2;
        return 0;
    }
    e->etat = (choix == e->bonneReponse) ? 1 : -1;
    return (e->etat == 1);
}
