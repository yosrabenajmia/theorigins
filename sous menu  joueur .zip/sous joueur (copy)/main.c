#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include "fonction.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>


void displayMultiplayerScreen(SDL_Surface *screen, Mix_Chunk *clickSound, int *multiplayerScreen);

int main(int argc, char *argv[]) {
    SDL_Surface *screen = NULL;
    SDL_Surface *background = NULL;
    SDL_Surface *button1 = NULL, *button1_hover = NULL;
    SDL_Surface *button2 = NULL, *button2_hover = NULL;




    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "Unable to initialize SDL: %s\n", SDL_GetError());
        return 1;
    }

    // Initialize SDL_mixer
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        fprintf(stderr, "Unable to initialize SDL_mixer: %s\n", Mix_GetError());
        SDL_Quit();
        return 1;
    }

    // Load the click sound
    Mix_Chunk *clickSound = Mix_LoadWAV("click.wav");
    if (clickSound == NULL) {
        fprintf(stderr, "Failed to load click sound: %s\n", Mix_GetError());
        Mix_CloseAudio();
        SDL_Quit();
        return 1;
    }

    // Set the screen size to match the background (900x500)
    screen = SDL_SetVideoMode(900, 500, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (screen == NULL) {
        fprintf(stderr, "Unable to set video mode: %s\n", SDL_GetError());
        Mix_FreeChunk(clickSound);
        Mix_CloseAudio();
        SDL_Quit();
        return 1;
    }

    // Load images
    background = loadImage("BG.png");
    button1 = loadImage("BMOJ_1.png");
    button1_hover = loadImage("BMOJ_2.png");
    button2 = loadImage("BMU_1.png");
    button2_hover = loadImage("BMU_2.png");

    // Check if all images loaded successfully
    if (background == NULL || button1 == NULL || button1_hover == NULL ||
        button2 == NULL || button2_hover == NULL) {
        fprintf(stderr, "Failed to load one or more images.\n");
        Mix_FreeChunk(clickSound);
        Mix_CloseAudio();
        SDL_Quit();
        return 1;
    }

    // Button positions and sizes
    SDL_Rect button1_rect = {135, 200, 229, 130}; // BMOJ_1.png position and size
    SDL_Rect button2_rect = {500, 200, 229, 130}; // BMU_1.png position and size

    // Main event loop
    SDL_Event event;
    int running = 1;
    int mouseX, mouseY;
    int hoverButton1 = 0, hoverButton2 = 0;
    int multiplayerScreen = 0; // Flag to check if multiplayer screen is active

    while (running) {
        // Clear the screen with the background
        applySurface(0, 0, background, screen);

        // Check mouse position
        SDL_GetMouseState(&mouseX, &mouseY);

        if (!multiplayerScreen) {
            // Main menu screen
            hoverButton1 = isMouseOver(mouseX, mouseY, button1_rect);
            hoverButton2 = isMouseOver(mouseX, mouseY, button2_rect);

            // Apply buttons to the screen
            applySurface(button1_rect.x, button1_rect.y, hoverButton1 ? button1_hover : button1, screen);
            applySurface(button2_rect.x, button2_rect.y, hoverButton2 ? button2_hover : button2, screen);

            // Handle events
            while (SDL_PollEvent(&event)) {
                switch (event.type) {
                    case SDL_QUIT:
                        running = 0;
                        break;

                    case SDL_MOUSEBUTTONDOWN:
                        if (event.button.button == SDL_BUTTON_LEFT) {
                            if (hoverButton1) {
                                Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                                printf("Button 1 clicked!\n");
                            }
                            if (hoverButton2) {
                                Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                                printf("Button 2 clicked!\n");
                                multiplayerScreen = 1; // Switch to multiplayer screen
                            }
                        }
                        break;

                    default:
                        break;
                }
            }
        } else {
            // Multiplayer screen
            displayMultiplayerScreen(screen, clickSound, &multiplayerScreen);
        }

        // Update the screen
        SDL_Flip(screen);
    }

    // Free surfaces
    SDL_FreeSurface(background);
    SDL_FreeSurface(button1);
    SDL_FreeSurface(button1_hover);
    SDL_FreeSurface(button2);
    SDL_FreeSurface(button2_hover);

    // Free the click sound
    Mix_FreeChunk(clickSound);

    // Close SDL_mixer
    Mix_CloseAudio();

    // Quit SDL
    SDL_Quit();

    return 0;
}

void displayMultiplayerScreen(SDL_Surface *screen, Mix_Chunk *clickSound, int *multiplayerScreen) {
    SDL_Surface *avatar1 = loadImage("BA1_1O.png");
    SDL_Surface *avatar1_hover = loadImage("BA1_2.png");
    SDL_Surface *avatar2 = loadImage("BA2_1.png");
    SDL_Surface *avatar2_hover = loadImage("BA2_1O.png");
    SDL_Surface *input1 = loadImage("BI1_2.png");
    SDL_Surface *input1_hover = loadImage("BI1_1.png");
    SDL_Surface *input2 = loadImage("BI2_1.png");
    SDL_Surface *input2_hover = loadImage("BI2_2.png");
    SDL_Surface *buttonRetour = loadImage("BR_1.png");
    SDL_Surface *buttonRetour_hover = loadImage("BR_2.png");

    // Button positions and sizes
    SDL_Rect avatar1_rect = {50, 50, 229, 130}; // Avatar 1 position and size
    SDL_Rect avatar2_rect = {500, 50, 229, 130}; // Avatar 2 position and size
    SDL_Rect input1_rect = {50, 200, 229, 130}; // Input 1 position and size
    SDL_Rect input2_rect = {500, 200, 229, 130}; // Input 2 position and size
    SDL_Rect buttonRetour_rect = {650, 352, 229, 130}; // Retour button position and size

    // Check mouse position
    int mouseX, mouseY;
    SDL_GetMouseState(&mouseX, &mouseY);

    // Check if the mouse is over buttons
    int hoverAvatar1 = isMouseOver(mouseX, mouseY, avatar1_rect);
    int hoverAvatar2 = isMouseOver(mouseX, mouseY, avatar2_rect);
    int hoverInput1 = isMouseOver(mouseX, mouseY, input1_rect);
    int hoverInput2 = isMouseOver(mouseX, mouseY, input2_rect);
    int hoverRetour = isMouseOver(mouseX, mouseY, buttonRetour_rect);

    // Apply buttons to the screen
    applySurface(avatar1_rect.x, avatar1_rect.y, hoverAvatar1 ? avatar1_hover : avatar1, screen);
    applySurface(avatar2_rect.x, avatar2_rect.y, hoverAvatar2 ? avatar2_hover : avatar2, screen);
    applySurface(input1_rect.x, input1_rect.y, hoverInput1 ? input1_hover : input1, screen);
    applySurface(input2_rect.x, input2_rect.y, hoverInput2 ? input2_hover : input2, screen);
    applySurface(buttonRetour_rect.x, buttonRetour_rect.y, hoverRetour ? buttonRetour_hover : buttonRetour, screen);

    // Handle events
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_MOUSEBUTTONDOWN:
                if (event.button.button == SDL_BUTTON_LEFT) {
                    if (hoverAvatar1) {
                        Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                        printf("Avatar 1 clicked!\n");
                    }
                    if (hoverAvatar2) {
                        Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                        printf("Avatar 2 clicked!\n");
                    }
                    if (hoverInput1) {
                        Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                        printf("Input 1 clicked!\n");
                    }
                    if (hoverInput2) {
                        Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                        printf("Input 2 clicked!\n");
                    }
                    if (hoverRetour) {
                        Mix_PlayChannel(-1, clickSound, 0); // Play click sound
                        printf("Retour button clicked!\n");
                        *multiplayerScreen = 0; // Return to main menu
                    }
                }
                break;

            default:
                break;
        }
    }

    // Free surfaces
    SDL_FreeSurface(avatar1);
    SDL_FreeSurface(avatar1_hover);
    SDL_FreeSurface(avatar2);
    SDL_FreeSurface(avatar2_hover);
    SDL_FreeSurface(input1);
    SDL_FreeSurface(input1_hover);
    SDL_FreeSurface(input2);
    SDL_FreeSurface(input2_hover);
    SDL_FreeSurface(buttonRetour);
    SDL_FreeSurface(buttonRetour_hover);
}
