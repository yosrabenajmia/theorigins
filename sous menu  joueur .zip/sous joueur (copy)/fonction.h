#ifndef FONCTION_H
#define FONCTION_H

#include <SDL/SDL.h>

// Function declarations
SDL_Surface* loadImage(const char *filename);
void applySurface(int x, int y, SDL_Surface *source, SDL_Surface *destination);
int isMouseOver(int mouseX, int mouseY, SDL_Rect buttonRect);

#endif
