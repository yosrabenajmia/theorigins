#include "game.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_gfxPrimitives.h>
#include <SDL/SDL_rotozoom.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

#define PUZZLE_ROWS     3
#define PUZZLE_COLS     3
#define TILE_SIZE       341
#define REMOVED_TILES   3
#define SCREEN_W        1500
#define SCREEN_H        (PUZZLE_ROWS * TILE_SIZE)

static SDL_Surface  *puzzleTiles[9];
static int           puzzleState[9];     // -1 = empty, else tile idx
static SDL_Surface  *sideTiles[REMOVED_TILES];
static int           sideIdx[REMOVED_TILES];
static SDL_Rect      sidePos[REMOVED_TILES];

static int dragging   = -1;
static SDL_Rect dragDst;
static int offsetX, offsetY;

static int hoverSlot  = -1;
static int movesCount = 0;

// Timer:
static Uint32 startTicks;
const Uint32 TIME_LIMIT = 30 * 1000;  


void drawTimer(SDL_Surface *screen) {
    Uint32 elapsed = SDL_GetTicks() - startTicks;
    Uint32 remaining = (TIME_LIMIT > elapsed) ? (TIME_LIMIT - elapsed) : 0;
    float percentage = (float)remaining / TIME_LIMIT;

    // Color interpolation: green -> yellow -> red
    Uint8 r = (Uint8)(255 * (1.0f - percentage));
    Uint8 g = (Uint8)(255 * percentage);
    Uint8 b = 0;

    int centerX = 100, centerY = 100;
    int radius = 60;
    int thickness = 10;

    // Draw base circle (background of the clock)
    circleRGBA(screen, centerX, centerY, radius, 255, 255, 255, 50);

    // Draw circular countdown progress ring (clock style)
    int angleStart = 270; // Start from top
    int angleEnd = angleStart + (int)(360.0f * percentage);

    for (int i = 0; i < thickness; ++i) {
        arcRGBA(screen, centerX, centerY, radius - i, angleStart, angleEnd, r, g, b, 255);
    }

    // Draw clock center and border
    filledCircleRGBA(screen, centerX, centerY, radius - thickness - 2, 30, 30, 30, 200); // Inner face
    circleRGBA(screen, centerX, centerY, radius, 255, 255, 255, 255); // Border

}
void startTimer() {
    startTicks = SDL_GetTicks();
}

int isTimeUp() {
    return (SDL_GetTicks() - startTicks) >= TIME_LIMIT;
}

// Draw animated background gradient:
static void drawBackground(SDL_Surface *screen) {
    Uint32 t = SDL_GetTicks() / 10;
    for (int y = 0; y < screen->h; y++) {
        /* hue shift over time: */
        Uint8 r = (Uint8)((sin((y + t) * 0.01) * 0.5 + 0.5) * 100 + 50);
        Uint8 g = (Uint8)((sin((y + t) * 0.012) * 0.5 + 0.5) * 100 + 50);
        Uint8 b = (Uint8)((sin((y + t) * 0.014) * 0.5 + 0.5) * 100 + 50);
        SDL_Rect line = {0, y, screen->w, 1};
        SDL_FillRect(screen, &line, SDL_MapRGB(screen->format, r, g, b));
    }
}

// Draw timer bar + moves via TTF:


// Helper: get grid slot under mouse (or -1)
static int findSlot(int mx, int my) {
    if (mx < 0 || my < 0) return -1;
    int c = mx / TILE_SIZE, r = my / TILE_SIZE;
    if (c >= PUZZLE_COLS || r >= PUZZLE_ROWS) return -1;
    return r*PUZZLE_COLS + c;
}
// Loading tile images
// Removing random tiles to create the playable puzzle
void initPuzzle() {
    srand((unsigned)time(NULL));
    // Randomly select a tile 
    int set = rand()%3 + 1;

    for (int i = 0; i < 9; i++) {
        char path[64];
        //loading JPEG version
        snprintf(path,sizeof(path),"assets/tiles/%d/%d.jpeg",set,i+1);
        puzzleTiles[i] = IMG_Load(path);
        // If JPEG fails, try PNG version
        if (!puzzleTiles[i]) {
            snprintf(path,sizeof(path),"assets/tiles/%d/%d.png",set,i+1);
            puzzleTiles[i] = IMG_Load(path);
        }
        // Initialize each tile starts in correct position
        puzzleState[i] = i;
    }
    // Remove 3 random tiles to create the puzzle
    int rem=0;
    while (rem<REMOVED_TILES) {
        // Select random tile 
        int idx=rand()%9; // Remember original position
        // Check if we already selected this index
        int dup=0;
        for(int j=0;j<rem;j++) if(sideIdx[j]==idx) dup=1;
        if(dup) continue; // Skip duplicates
        sideIdx[rem]=idx;
        sideTiles[rem]=puzzleTiles[puzzleState[idx]];
        puzzleState[idx] = -1; // Mark this position as empty in the puzzle
        sidePos[rem].x = PUZZLE_COLS * TILE_SIZE + 50; // Right side
        sidePos[rem].y = 50 + rem * (TILE_SIZE + 20);  // Vertical spacing
        sidePos[rem].w = TILE_SIZE; // Maintain original dimensions
        sidePos[rem].h = TILE_SIZE;
        rem++; // Move to next removal slot
    }
// Reset game state variables
    dragging = -1;
    movesCount = 0;
}
// Returns: 1 if puzzle is solved, 0 otherwise
int isSolved() {
    for (int i=0;i<9;i++)
// Compare each position's content with value
        if (puzzleState[i]!=i) return 0;
    return 1;
}

int handlePuzzle(SDL_Surface *screen, Mix_Chunk *clickSound) {
    

    SDL_Event ev;
    while (SDL_PollEvent(&ev)) {
        if (ev.type==SDL_QUIT) exit(0);

        if (ev.type==SDL_MOUSEBUTTONDOWN && ev.button.button==SDL_BUTTON_LEFT) {
            int mx=ev.button.x, my=ev.button.y;
            // pick up side tile?
            for(int i=0;i<REMOVED_TILES;i++){
                if (sideIdx[i]<0) continue;
                SDL_Rect *sp=&sidePos[i];
                if (mx>=sp->x && mx<=sp->x+sp->w &&
                    my>=sp->y && my<=sp->y+sp->h)
                {
                    dragging=i;
                    offsetX = mx - sp->x;
                    offsetY = my - sp->y;
                    dragDst = *sp;
                    Mix_PlayChannel(-1, clickSound, 0);
                    break;
                }
            }
        }
        if (ev.type==SDL_MOUSEMOTION && dragging>=0) {
            dragDst.x = ev.motion.x - offsetX;
            dragDst.y = ev.motion.y - offsetY;
        }
        if (ev.type==SDL_MOUSEBUTTONUP && dragging>=0) {
            int slot=findSlot(ev.button.x, ev.button.y);
            if (slot>=0 && puzzleState[slot]==-1) {
                puzzleState[slot] = sideIdx[dragging];
                sideIdx[dragging]  = -1;
                movesCount++;
            }
            else {
                    dragDst = sidePos[dragging]; 
            }
            dragging = -1;
        }
    }

    // update hover
    int mx,my; SDL_GetMouseState(&mx,&my);
    int hs = findSlot(mx,my);
    hoverSlot = (hs>=0 && puzzleState[hs]==-1) ? hs : -1;

    // draw
    drawBackground(screen);

    // grid
    for (int i=0;i<9;i++){
        int r=i/PUZZLE_COLS, c=i%PUZZLE_COLS;
        SDL_Rect d={c*TILE_SIZE,r*TILE_SIZE,0,0};

        if (puzzleState[i]>=0) {
            SDL_BlitSurface(puzzleTiles[puzzleState[i]],NULL,screen,&d);
        } else {
            // pulsing red hover
            Uint8 alpha = 128 + (Uint8)(127*sin(SDL_GetTicks()/250.0));
            boxRGBA(screen,d.x,d.y,
                    d.x+TILE_SIZE, d.y+TILE_SIZE,
                    255,0,0, (i==hoverSlot?alpha:100));
            rectangleRGBA(screen,d.x,d.y,
                          d.x+TILE_SIZE,d.y+TILE_SIZE,
                          255,255,255,200);
        }
    }

    // side tiles
    for(int i=0;i<REMOVED_TILES;i++){
        if(sideIdx[i]<0) continue;
        SDL_Surface *src = sideTiles[i];
        SDL_Rect  *sp  = &sidePos[i];
        if (i!=dragging)
            SDL_BlitSurface(src,NULL,screen,sp);
    }

    // dragging (zoom slightly)
    if (dragging>=0) {
        double scale = 1.2;
        SDL_Surface *z = rotozoomSurface(
            sideTiles[dragging], 0, scale, 1);
        SDL_Rect dd = dragDst;
        dd.x -= (z->w - sidePos[dragging].w)/2;
        dd.y -= (z->h - sidePos[dragging].h)/2;
        SDL_BlitSurface(z,NULL,screen,&dd);
        SDL_FreeSurface(z);
    }

    // overlay UI
    drawTimer(screen);
    SDL_Flip(screen);
    SDL_Delay(16);

    return isSolved();
}

void cleanPuzzle() {
// Loop through all 9 puzzle tiles (3x3 grid)
    for(int i=0;i<9;i++)
// Check if the tile surface exists (is not NULL)
        if(puzzleTiles[i]) SDL_FreeSurface(puzzleTiles[i]); // Free the SDL_Surface memory for this tile
}

//rotozoom
void showRotoZoom(SDL_Surface *screen, const char *path) {
    SDL_Surface *img = IMG_Load(path);
    if(!img) return;
    Uint32 st=SDL_GetTicks(); // Get the current time in milliseconds (ms)
    while (SDL_GetTicks()-st<2000) {
        double t=(SDL_GetTicks()-st)/2000.0; // Calculate normalized time (0 to 2 seconds)
        double ang = t*360; // Calculate rotation angle: 0° to 360°
        double zoom = 1.0 + 0.5*t; // Calculate zoom starts at 1.0, increases to 1.5 over 2 seconds
        SDL_Surface *rz = rotozoomSurface(img,ang,zoom,1); // Create a rotated and zoomed version of the original image
        int x=(screen->w-rz->w)/2, y=(screen->h-rz->h)/2; // Calculate centered position for the transformed image

        SDL_FillRect(screen,NULL,0); // Clear screen with black (0)
        SDL_BlitSurface(rz,NULL,screen,(SDL_Rect[]){ {x,y,0,0} }); // Blit transformed image to the centered position
        SDL_Flip(screen); // Update screen
        SDL_FreeSurface(rz);
        SDL_Delay(16);
    }
    SDL_FreeSurface(img);
}
