#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <stdio.h>
#include "game.h"

int main() {
    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "Erreur d'initialisation de SDL: %s\n", SDL_GetError());
        return 1;
    }

    // Création de la fenêtre
    SDL_Surface *screen = SDL_SetVideoMode(1500, 1023, 32, SDL_SWSURFACE);
    SDL_WM_SetCaption("Puzzle & Memory Game", NULL);
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        fprintf(stderr, "Erreur d'initialisation de SDL_mixer: %s\n", Mix_GetError());
        return 1;
    }

    // Load sound effects
    Mix_Chunk *clickSound = Mix_LoadWAV("assets/click.wav");
    Mix_Chunk *winSound = Mix_LoadWAV("assets/winner.wav");
    Mix_Chunk *loseSound = Mix_LoadWAV("assets/loser.wav");

    if (!clickSound) {
        fprintf(stderr, "Erreur de chargement du son de clic: %s\n", Mix_GetError());
        return 1;
    }

    if (!winSound || !loseSound) {
        fprintf(stderr, "Erreur de chargement du son: %s\n", Mix_GetError());
        return 1;
    }

    int puzzleWon = 0;

    // --- Puzzle ---
    initPuzzle();
    startTimer();
    // Boucle du puzzle
    while(!isTimeUp() && !puzzleWon) {
        puzzleWon = handlePuzzle(screen, clickSound);
    }
    cleanPuzzle();

    // Si puzzle gagné, affiche l'image de victoire avec rotozoom
    if(puzzleWon) {
        Mix_PlayChannel(-1, winSound, 0);  // Play winning sound for puzzle
        showRotoZoom(screen, "assets/winner.png");
    } else {
      
        
            Mix_PlayChannel(-1, loseSound, 0);  // Play losing sound
            showRotoZoom(screen, "assets/loser.png");
        
    }

    // Wait for the sound to finish playing before quitting
    SDL_Delay(2000);  // Wait for 2 seconds to let the sound play

    // Clean up
    Mix_FreeChunk(clickSound);
    Mix_FreeChunk(winSound);
    Mix_FreeChunk(loseSound);

    SDL_Quit();
    return 0;
}
