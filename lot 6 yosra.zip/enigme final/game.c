#include "game.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_rotozoom.h>
#include <SDL/SDL_gfxPrimitives.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <math.h>


static Uint32 startTime;
const Uint32 TIME_LIMIT = 30000; // 30 seconds

void startTimer() {
    startTime = SDL_GetTicks();
}

int isTimeUp() {
    return (SDL_GetTicks() - startTime) >= TIME_LIMIT; //returns the number of milliseconds
}

void drawTimer(SDL_Surface *screen) {
    Uint32 elapsed = SDL_GetTicks() - startTime; //calculates how many milliseconds have passed since startTime
    Uint32 remaining = (TIME_LIMIT > elapsed) ? (TIME_LIMIT - elapsed) : 0; // how much time is left before a time limit
    float percentage = (float)remaining / TIME_LIMIT; //Converts remaining to a float to ensure  division then Divides it

    // Color interpolation: green -> yellow -> red
    Uint8 r = (Uint8)(255 * (1.0f - percentage));
    Uint8 g = (Uint8)(255 * percentage);
    Uint8 b = 0; //Calculates a color from red to green based on percentage

    int centerX = 100, centerY = 100;
    int radius = 60;
    int thickness = 10;//Sets the center of a circle at (100, 100) with a radius of 60.thickness defines the width of the circle’s outline

    // Draw base circle (background of the clock)
    circleRGBA(screen, centerX, centerY, radius, 255, 255, 255, 50);

    // Draw circular countdown progress ring (clock style)
    int angleStart = 270; // Start from top
    int angleEnd = angleStart + (int)(360.0f * percentage);

    for (int i = 0; i < thickness; ++i) {
        arcRGBA(screen, centerX, centerY, radius - i, angleStart, angleEnd, r, g, b, 255);
    }

    // Draw clock center and border
    filledCircleRGBA(screen, centerX, centerY, radius - thickness - 2, 30, 30, 30, 200); // Inner face
    circleRGBA(screen, centerX, centerY, radius, 255, 255, 255, 255); // Border

    // Display remaining time in seconds
    char timerText[50];
    snprintf(timerText, sizeof(timerText), "%02d", remaining / 1000);

    // Optionally blink if under 5 seconds
    int blink = (remaining < 5000) && ((SDL_GetTicks() / 250) % 2 == 0);

    if (!blink) {
        stringRGBA(screen, centerX - 10, centerY - 4, timerText, 255, 255, 255, 255);
    }

    // Optional: add clock ticks around
    for (int angle = 0; angle < 360; angle += 30) {
        float rad = angle * M_PI / 180.0f;
        int x1 = centerX + (int)((radius - 2) * cos(rad));
        int y1 = centerY + (int)((radius - 2) * sin(rad));
        int x2 = centerX + (int)((radius - thickness - 5) * cos(rad));
        int y2 = centerY + (int)((radius - thickness - 5) * sin(rad));
        lineRGBA(screen, x1, y1, x2, y2, 200, 200, 200, 80);
    }
}
// Puzzle game variables et fonctions
#define PUZZLE_ROWS 3
#define PUZZLE_COLS 3
#define PUZZLE_TILE_WIDTH 341
#define PUZZLE_TILE_HEIGHT 341

static SDL_Surface *puzzleTiles[9];
static int puzzleOrder[9];
static int selectedTile = -1; // -1 signifie aucune sélection

// Échange deux tuiles
static void swapTiles(int i, int j) {
    int temp = puzzleOrder[i];
    puzzleOrder[i] = puzzleOrder[j];
    puzzleOrder[j] = temp;
}

void initPuzzle() {
    int i;
    // Charger les images des tuiles (1.jpeg à 9.jpeg dans assets/tiles/)
    for(i = 0; i < 9; i++){
        char path[128];
        snprintf(path, sizeof(path), "assets/tiles/%d.jpeg", i+1);
        puzzleTiles[i] = IMG_Load(path);
        if(!puzzleTiles[i]){
            fprintf(stderr, "Erreur de chargement de %s\n", path);
            exit(1);
        }
        puzzleOrder[i] = i; // ordre correct
    }
    // Mélanger les tuiles
    srand(time(NULL));
    for(i = 0; i < 9; i++){
        int j = rand() % 9;
        swapTiles(i, j);
    }
    selectedTile = -1;
}

// Vérifie si le puzzle est résolu (les indices doivent être dans l'ordre)
static int isPuzzleSolved() {
    for(int i = 0; i < 9; i++){
        if(puzzleOrder[i] != i)
            return 0;
    }
    return 1;
}

int handlePuzzle(SDL_Surface *screen) {
    SDL_Event event;
    int solved = 0;
    
    // Gestion des événements
    while(SDL_PollEvent(&event)){
        if(event.type == SDL_QUIT){
            exit(0);
        }
        if(event.type == SDL_MOUSEBUTTONDOWN){
            int x = event.button.x;
            int y = event.button.y;
            // Calculer l'indice de la case cliquée
            int col = x / PUZZLE_TILE_WIDTH;
            int row = y / PUZZLE_TILE_HEIGHT;
            if(col < PUZZLE_COLS && row < PUZZLE_ROWS) {
                int index = row * PUZZLE_COLS + col;
                if(selectedTile == -1) {
                    selectedTile = index;
                } else {
                    // Échanger la pièce sélectionnée avec celle cliquée
                    swapTiles(selectedTile, index);
                    selectedTile = -1;
                    // Vérifier si le puzzle est résolu
                    if(isPuzzleSolved()){
                        solved = 1;
                    }
                }
            }
        }
    }
    // Effacer l'écran avant de redessiner
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    // Rendu du puzzle
    for(int i = 0; i < 9; i++){
        int row = i / PUZZLE_COLS;
        int col = i % PUZZLE_COLS;
        SDL_Rect dest = { col * PUZZLE_TILE_WIDTH, row * PUZZLE_TILE_HEIGHT, 0, 0 };
        SDL_BlitSurface(puzzleTiles[puzzleOrder[i]], NULL, screen, &dest);
        // Dessiner un cadre sur la tuile sélectionnée
        if(i == selectedTile){
            SDL_Rect border = dest;
            // Utiliser un remplissage transparent en rouge pour le cadre
            boxRGBA(screen, border.x, border.y, border.x + PUZZLE_TILE_WIDTH - 1, border.y + PUZZLE_TILE_HEIGHT - 1, 255, 0, 0, 100);
        }
    }
    // Dessiner le timer
    drawTimer(screen);
    SDL_Flip(screen);
    SDL_Delay(50);
    return solved;
}

void cleanPuzzle() {
    for(int i = 0; i < 9; i++){
        if(puzzleTiles[i])
            SDL_FreeSurface(puzzleTiles[i]);
    }
}

// Memory game variables et fonctions
#define MEMORY_CARDS 6
#define MEMORY_ROWS 2
#define MEMORY_COLS 3
#define MEMORY_CARD_WIDTH 150
#define MEMORY_CARD_HEIGHT 150

static SDL_Surface *memoryFront[3]; // images pour m1.jpg, m2.jpg, m3.jpg
static SDL_Surface *memoryBack;
static int memoryOrder[MEMORY_CARDS];    // Contient 0,0,1,1,2,2
static int memoryRevealed[MEMORY_CARDS];   // 0: caché, 1: révélé (définitif)
 
void initMemory() {
    int i;
    // Charger les images de face pour chaque carte (assets/memory/m1.jpg, m2.jpg, m3.jpg)
    for(i = 0; i < 3; i++){
        char path[128];
        snprintf(path, sizeof(path), "assets/memory/M%d.jpg", i+1);
        memoryFront[i] = IMG_Load(path);
        if(!memoryFront[i]){
            fprintf(stderr, "Erreur de chargement de %s\n", path);
            exit(1);
        }
    }
    // Charger l'image de dos
    memoryBack = IMG_Load("assets/memory/back.png");
    if(!memoryBack){
        fprintf(stderr, "Erreur de chargement de assets/memory/back.jpg\n");
        exit(1);
    }
    // Préparer l'ordre des cartes : 0,0,1,1,2,2
    memoryOrder[0] = 0; memoryOrder[1] = 0;
    memoryOrder[2] = 1; memoryOrder[3] = 1;
    memoryOrder[4] = 2; memoryOrder[5] = 2;
    // Mélanger l'ordre
    srand(time(NULL));
    for(i = 0; i < MEMORY_CARDS; i++){
        int j = rand() % MEMORY_CARDS;
        int temp = memoryOrder[i];
        memoryOrder[i] = memoryOrder[j];
        memoryOrder[j] = temp;
    }
    for(i = 0; i < MEMORY_CARDS; i++){
        memoryRevealed[i] = 0;
    }
}
int handleMemory(SDL_Surface *screen) {
    SDL_Event event;
    int finished = 0;
    int firstSelection = -1, secondSelection = -1;
    Uint32 flipTime = 0;
    int waiting = 0;

    // Dimensions de la grille mémoire
    int gridWidth = MEMORY_COLS * MEMORY_CARD_WIDTH;
    int gridHeight = MEMORY_ROWS * MEMORY_CARD_HEIGHT;

    // Calcul des marges pour centrer la grille
    int offsetX = (screen->w - gridWidth) / 2;
    int offsetY = (screen->h - gridHeight) / 2;

    while (!finished && !isTimeUp()) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                exit(0);
            }
            if (event.type == SDL_MOUSEBUTTONDOWN && !waiting) {
                int x = event.button.x - offsetX;
                int y = event.button.y - offsetY;
                if (x >= 0 && y >= 0) {
                    int col = x / MEMORY_CARD_WIDTH;
                    int row = y / MEMORY_CARD_HEIGHT;
                    if (col < MEMORY_COLS && row < MEMORY_ROWS) {
                        int index = row * MEMORY_COLS + col;
                        if (memoryRevealed[index] == 0) {
                            if (firstSelection == -1)
                                firstSelection = index;
                            else if (firstSelection != index && secondSelection == -1)
                                secondSelection = index;
                        }
                    }
                }
            }
        }

        // Effacer l’écran
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));

        // Rendu du plateau mémoire centré
        for (int i = 0; i < MEMORY_CARDS; i++) {
            int row = i / MEMORY_COLS;
            int col = i % MEMORY_COLS;
            SDL_Rect dest = {
                offsetX + col * MEMORY_CARD_WIDTH,
                offsetY + row * MEMORY_CARD_HEIGHT,
                0, 0
            };
            if (memoryRevealed[i] || i == firstSelection || i == secondSelection) {
                SDL_BlitSurface(memoryFront[memoryOrder[i]], NULL, screen, &dest);
            } else {
                SDL_BlitSurface(memoryBack, NULL, screen, &dest);
            }
        }

        // Afficher le timer
        drawTimer(screen);
        SDL_Flip(screen);
        SDL_Delay(50);

        // Si deux cartes ont été sélectionnées
        if (firstSelection != -1 && secondSelection != -1 && !waiting) {
            waiting = 1;
            flipTime = SDL_GetTicks();
        }

        // Vérifie si le délai est passé pour retourner les cartes
        if (waiting && SDL_GetTicks() - flipTime >= 1000) {
            if (memoryOrder[firstSelection] == memoryOrder[secondSelection]) {
                memoryRevealed[firstSelection] = 1;
                memoryRevealed[secondSelection] = 1;
            }
            firstSelection = -1;
            secondSelection = -1;
            waiting = 0;
        }

        // Vérifier si toutes les cartes sont révélées
        int allRevealed = 1;
        for (int i = 0; i < MEMORY_CARDS; i++) {
            if (memoryRevealed[i] == 0)
                allRevealed = 0;
        }
        if (allRevealed)
            finished = 1;
    }

    return finished;
}


void cleanMemory() {
    for(int i = 0; i < 3; i++){
        if(memoryFront[i])
            SDL_FreeSurface(memoryFront[i]);
    }
    if(memoryBack)
        SDL_FreeSurface(memoryBack);
}

// Rotozoom (affichage de l'image avec effet)

void showRotoZoom(SDL_Surface *screen, const char *imagePath) {
    SDL_Surface *img = IMG_Load(imagePath);
    if (!img) return;

    const int duration = 3000; // Animation duration in milliseconds
    Uint32 startTime = SDL_GetTicks();
    
    // Animation loop: updates roughly 60 FPS
    while (SDL_GetTicks() - startTime < duration) {
        Uint32 elapsed = SDL_GetTicks() - startTime;
        // Calculate the current angle (from 0 to 360 degrees)
        double angle = ((double)elapsed / duration) * 360.0;
        // Calculate the zoom factor from 1.0 up to 1.2
        double zoom = 1.0 + (((double)elapsed / duration) * 2);
        
        // Create a new surface with the current rotation and zoom values
        SDL_Surface *zoomed = rotozoomSurface(img, angle, zoom, 1);
        if (!zoomed) break;  // Safety check
        
        // Center the zoomed image on the screen
        int x = (screen->w - zoomed->w) / 2;
        int y = (screen->h - zoomed->h) / 2;
        SDL_Rect dest = { x, y, 0, 0 };

        // Clear screen, blit the new frame, and update the display
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
        SDL_BlitSurface(zoomed, NULL, screen, &dest);
        SDL_Flip(screen);

        SDL_FreeSurface(zoomed);

        SDL_Delay(16);  // Roughly 60 FPS
    }

    SDL_FreeSurface(img);
}
