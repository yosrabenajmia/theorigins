#ifndef GAME_H
#define GAME_H

#include <SDL/SDL.h>

// Timer
void startTimer();
int isTimeUp();
void drawTimer(SDL_Surface *screen) ;
// Puzzle game functions
void initPuzzle();
int handlePuzzle(SDL_Surface *screen);
void cleanPuzzle();

// Memory game functions
void initMemory();
int handleMemory(SDL_Surface *screen);
void cleanMemory();

// Rotozoom effect (affiche l'image pendant quelques secondes)
void showRotoZoom(SDL_Surface *screen, const char *imagePath);

#endif
