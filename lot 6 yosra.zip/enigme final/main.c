#include <SDL/SDL.h>
#include <stdio.h>
#include "game.h"

int main() {
    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "Erreur d'initialisation de SDL: %s\n", SDL_GetError());
        return 1;
    }
    // Création de la fenêtre (1023x1023)
    SDL_Surface *screen = SDL_SetVideoMode(1023, 1023, 32, SDL_SWSURFACE);
    SDL_WM_SetCaption("Puzzle & Memory Game", NULL);
    
    int puzzleWon = 0;
    int memoryWon = 0;
    
    // --- Puzzle ---
    initPuzzle();
    startTimer();
    // Boucle du puzzle
    while(!isTimeUp() && !puzzleWon) {
        puzzleWon = handlePuzzle(screen);
    }
    cleanPuzzle();
    
    // Si puzzle gagné, affiche l'image de victoire avec rotozoom
    if(puzzleWon) {
        showRotoZoom(screen, "assets/winner.png");
    } else {
        // --- Memory game ---
        initMemory();
        startTimer();
        memoryWon = handleMemory(screen);
        cleanMemory();
        
        if(memoryWon)
            showRotoZoom(screen, "assets/winner.png");
        else
            showRotoZoom(screen, "assets/loser.png");
    }
    
    SDL_Quit();
    return 0;
}
