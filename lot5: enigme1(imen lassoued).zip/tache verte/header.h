#ifndef ENIGME_H
#define ENIGME_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>

#define SCREEN_WIDTH 1920
#define SCREEN_HEIGHT 1080

typedef struct {
    SDL_Surface *question;
    SDL_Surface *reponse1;
    SDL_Surface *reponse2;
    SDL_Surface *reponse3;
    SDL_Rect pos_question;
    SDL_Rect pos_reponse1;
    SDL_Rect pos_reponse2;
    SDL_Rect pos_reponse3;
    TTF_Font *font;
    SDL_Color textColor;
    int etat;         
    int bonneReponse;
    SDL_Surface *background;
    int *questionsUtilisees;
    int totalQuestions;
    int tempsRestant;
    Uint32 debutTemps;
} Enigme;

void initEnigme(Enigme *e);
void decomposer(char *chaine, Enigme *e);
void genererEnigme(Enigme *e, const char *nomfich);
void libererEnigme(Enigme *e);
int verifierReponse(Enigme *e, int choix);

#endif
