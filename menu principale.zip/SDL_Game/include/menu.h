#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

// Menu structure includes text fields for rendered text.
typedef struct {
    SDL_Surface *background;
    SDL_Surface *play_btn[2];      // Normal & hover
    SDL_Surface *options_btn[2];
    SDL_Surface *best_score_btn[2];
    SDL_Surface *history_btn[2];
    SDL_Surface *quit_btn[2];
    SDL_Rect pos_btn_play;
    SDL_Rect pos_btn_option;
    SDL_Rect pos_btn_best_score;
    SDL_Rect pos_btn_history;
    SDL_Rect pos_btn_quit;
    SDL_Surface *logo;
    SDL_Rect pos_logo;
    int hovered_play;
    int hovered_option;
    int hovered_best_score;
    int hovered_history;
    int hovered_quit;
    SDL_Rect textPos;       // Position for the text "THE ORIGIN"
    SDL_Surface *textSurface;  // Rendered text surface
} Menu;

void init_menu(Menu *m, SDL_Surface *ecran);
void afficher_menu(Menu *m, SDL_Surface *ecran);

#endif


	


	


	

