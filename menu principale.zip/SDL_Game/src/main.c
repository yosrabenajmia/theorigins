#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "menu.h"

int main() {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "SDL init error: %s\n", SDL_GetError());
        return 1;
    }

    if (TTF_Init() == -1) {
        fprintf(stderr, "TTF init error: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }


    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        fprintf(stderr, "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }


    Mix_Music *menu_music = Mix_LoadMUS("/home/rana/SDL_Game/assets/menu_music.mp3");
    if (!menu_music) {
        fprintf(stderr, "Failed to load music: %s\n", Mix_GetError());
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }


    if (Mix_PlayMusic(menu_music, -1) == -1) {
        fprintf(stderr, "Failed to play music: %s\n", Mix_GetError());
    }

    SDL_Surface *ecran = SDL_SetVideoMode(1472, 832, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (!ecran) {
        fprintf(stderr, "Video mode error: %s\n", SDL_GetError());
        Mix_FreeMusic(menu_music);
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    int quitter = 0;
    SDL_Event event;
    int indice_ecran = 0;
    Menu menu;

    init_menu(&menu, ecran);
    if (!menu.background) {
        SDL_Quit();
        return 1;
    }

    while (!quitter) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                quitter = 1;
            } else if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_ESCAPE) {
                    quitter = 1;
                }
            }
        }

        switch (indice_ecran) {
            case 0:
                afficher_menu(&menu, ecran);
                SDL_Flip(ecran);
                break;

        }
    }


    SDL_FreeSurface(menu.background);
    SDL_FreeSurface(menu.play_btn[0]);
    SDL_FreeSurface(menu.play_btn[1]);
    SDL_FreeSurface(menu.options_btn[0]);
    SDL_FreeSurface(menu.options_btn[1]);
    SDL_FreeSurface(menu.best_score_btn[0]);
    SDL_FreeSurface(menu.best_score_btn[1]);
    SDL_FreeSurface(menu.history_btn[0]);
    SDL_FreeSurface(menu.history_btn[1]);
    SDL_FreeSurface(menu.quit_btn[0]);
    SDL_FreeSurface(menu.quit_btn[1]);
    SDL_FreeSurface(menu.logo);
    if (menu.textSurface)
        SDL_FreeSurface(menu.textSurface);


    Mix_FreeMusic(menu_music);
    Mix_CloseAudio();

    TTF_Quit();
    SDL_Quit();
   
    return 0;
}


	


	

