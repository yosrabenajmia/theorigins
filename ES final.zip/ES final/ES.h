#ifndef ES_H
#define ES_H
#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct
{
	SDL_Surface *img ;
	SDL_Rect pos[20] ;
}image_enmie ;
typedef struct
{
	image_enmie etat_gauche;  
	image_enmie etat_droite;
	int mouv; 
	SDL_Rect pos; 
	int dir; 
}enmie ;
typedef struct
{
	SDL_Surface *img[4];
	SDL_Rect pos [10];
	int etat [10];
	int p;
}bonus;
typedef struct
{
SDL_Surface *img[3];
SDL_Rect pos;
int p;
}perso;
void initBonus(bonus*b);
void afficherBonus(SDL_Surface *screen , bonus b);
void annimerBonus(bonus*b);
int collision(SDL_Rect pos1,SDL_Rect pos2);

void init_enmie(enmie *e);
void affiche_enmie(SDL_Surface *screen , enmie e);
void deplacer_enmie(enmie *e) ;
void annimer_enmie(enmie *e) ;
int collision_trigo(SDL_Rect pos,SDL_Rect pos_perso);
void init_enmie2(enmie *e);
void deplacer_enmie2(enmie *e);
void initialiser_perso(perso *per);
void afficher_perso(SDL_Surface *screen,perso per);
void liberer_perso(perso*per);
#endif
