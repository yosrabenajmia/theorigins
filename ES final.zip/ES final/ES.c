#include"ES.h"

void init_enmie(enmie *e)
{
	e->etat_droite.img = IMG_Load("droite.png");
	e->etat_gauche.img = IMG_Load("gauche.png");
	e->mouv = 0;
	
e->pos.x= 0;
	e->pos.y= 0;
	e->pos.h=e->etat_droite.img->h;
	e->pos.w=e->etat_droite.img->w/19;
	e->dir=0;
	int x=0;
	for(int i=0 ; i<20 ; i++)
	{
		e->etat_droite.pos[i].x = x;
		e->etat_droite.pos[i].y=0;
		e->etat_droite.pos[i].h=e->pos.h;
		e->etat_droite.pos[i].w=e->pos.w;
		x=x+(e->pos.w); 
	}
	x=0;
	for(int i=19 ; i>=0 ; i--)
	{
		e->etat_gauche.pos[i].x = x;
		e->etat_gauche.pos[i].y=0;
		e->etat_gauche.pos[i].h=e->pos.h;
		e->etat_gauche.pos[i].w=e->pos.w;
		x=x+e->pos.w; 		
	}
}
void init_enmie2(enmie *e)
{
	e->etat_droite.img = IMG_Load("virbas.png");
	e->etat_gauche.img = IMG_Load("virhaut.png");
	e->mouv = 0;
	
e->pos.x= 0;
	e->pos.y= 0;
	e->pos.w=e->etat_droite.img->w;
	e->pos.h=e->etat_droite.img->h/19;
	e->dir=0;
	int y=0;
	for(int i=0 ; i<20 ; i++)
	{
		e->etat_droite.pos[i].y = y;
		e->etat_droite.pos[i].x=0;
		e->etat_droite.pos[i].w=e->pos.w;
		e->etat_droite.pos[i].h=e->pos.h;
		y=y+(e->pos.h); 
	}
	y=0;
	for(int i=19 ; i>=0 ; i--)
	{
		e->etat_gauche.pos[i].y = y;
		e->etat_gauche.pos[i].x=0;
		e->etat_gauche.pos[i].w=e->pos.w;
		e->etat_gauche.pos[i].h=e->pos.h;
		y=y+e->pos.h; 		
	}
}
void affiche_enmie(SDL_Surface *screen , enmie e)
{
	if(e.dir==0)
	{
		SDL_BlitSurface(e.etat_droite.img , &e.etat_droite.pos[e.mouv] , screen , &e.pos);
	}
	else
	{
		SDL_BlitSurface(e.etat_gauche.img , &e.etat_gauche.pos[e.mouv] , screen , &e.pos);
	}
}
void initialiser_perso(perso *per)
{
per->img[0]=IMG_Load("full.png");
per->img[1]=IMG_Load("red.png");
per->img[2]=IMG_Load("green.png");
per->pos.x=0;
per->pos.y=0;
per->pos.h=12;
per->pos.w=12;
per->p=0;
}
void afficher_perso(SDL_Surface *screen,perso per)
{
SDL_BlitSurface(per.img[per.p],NULL,screen,&per.pos);
}
void deplacer_enmie(enmie *e)
{
	if(e->dir==0)
	{
		e->pos.x = e->pos.x + 20 ;
	}
	else
	{
		e->pos.x-=20;
	}
}
void deplacer_enmie2(enmie *e)
{
	if(e->dir==0)
	{
		e->pos.y = e->pos.y + 20 ;
	}
	else
	{
		e->pos.y-=20;
	}
}
void annimer_enmie(enmie *e)
{
	e->mouv++;
	if(e->mouv == 18)
	{
		e->mouv=0;
		if(e->dir == 0) e->dir=1;
		else e->dir=0;
	}
}
int collision(SDL_Rect pos1,SDL_Rect pos2)
{
	int test=0;
    if(pos1.x + pos1.w > pos2.x && pos1.x < pos2.x + pos2.w && pos1.y + pos1.h 	> pos2.y && pos1.y < pos2.y + pos2.h) 
	{
		test=1;
	}
    return test;
}
int collision_trigo(SDL_Rect pos,SDL_Rect pos_perso)
{

	int X_perso,Y_perso,X,Y;
	double R1,R2,D1,D2;
	

	X_perso=pos_perso.x+pos_perso.w/2;
	Y_perso=pos_perso.y+pos_perso.h/2;


	X=pos.x+pos.w/2;
	Y=pos.y+pos.h/2;


	R1=sqrt(   (pos_perso.w/2)*(pos_perso.w/2) +(pos_perso.h/2)*(pos_perso.h/2) );
	R2=sqrt(   (pos.w/2)*(pos.w/2) +(pos.h/2)*(pos.h/2)   );

	D1=sqrt( (X_perso-X)*(X_perso-X) + (Y_perso-Y)*(Y_perso-Y)  );

	D2=R1+R2;
	if(D1<D2)
		return 0;
	else
		return 1;

}
void initBonus(bonus*b)
{
	b->img[0] = IMG_Load("1.png");
	b->img[1] = IMG_Load("2.png");
	b->img[2] = IMG_Load("3.png");
	b->img[3] = IMG_Load("4.png");
	b->p=0;
	for(int i=0 ; i<10 ; i++)
	{
		b->etat[i]=1;
		b->pos[i].x= i*100 + 200;
		if(i%2==0)
			b->pos[i].y=200;
		else
			b->pos[i].y=600;
		b->pos[i].h=50;
		b->pos[i].w=50;
	}
}void afficherBonus(SDL_Surface *screen , bonus b)
{
	for(int i=0 ; i<10 ;i++)
	{
		if(b.etat[i]==1)
			SDL_BlitSurface(b.img[b.p] , NULL , screen , &b.pos[i]);
	}
}
void liberer_perso(perso*per)
{
SDL_FreeSurface(per->img[0]);
SDL_FreeSurface(per->img[1]);
SDL_FreeSurface(per->img[2]);

}
void annimerBonus(bonus*b)
{
	b->p++;
	if(b->p==4)
	{
		b->p=0;
	}
}
