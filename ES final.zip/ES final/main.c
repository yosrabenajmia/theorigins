#include"ES.h"
int main()
{
/*****DECLARATION DES VARIABLE*****/
	//variable de la fenetre 
	SDL_Surface *screen;
	//variable du boucle
	int boucle=1;
	//variable d'evenement
	SDL_Event event;
	//background
	SDL_Surface *back ;
	SDL_Rect pos ;
        perso per;
        SDL_Surface *image = NULL;

      
	//variable d'enmie
	enmie e ;
        enmie e2;
        bonus b;
/*****INITIALISATION*****/
	back= IMG_Load("an1.png");
         image = IMG_Load("full.png");
	pos.x=0;pos.y=0;pos.w=back->w;pos.h=back->h;
	screen = SDL_SetVideoMode(pos.w , pos.h , 32 ,SDL_HWSURFACE|SDL_SRCALPHA);
	init_enmie(&e);
        init_enmie2(&e2);
        initialiser_perso(&per);
      initBonus(&b);
	
	while(boucle==1)
	{
	/*****AFFICHAGE*****/
		SDL_BlitSurface(back , NULL , screen , &pos); //affichage background
                

		affiche_enmie(screen , e);
                affiche_enmie(screen , e2);
                afficherBonus(screen , b);
                afficher_perso(screen,per);
		SDL_Flip(screen); //
	/*****LECTURE DES EVENEMENT*****/
		while(SDL_PollEvent(&event))
		{
		switch (event.type)
		{
			case SDL_QUIT:
				boucle =0;
				break;
                               case SDL_KEYDOWN:
                
					if(event.key.keysym.sym == SDLK_RIGHT)
					{
						per.pos.x += 10;
                                                break;
				
					}
					else if (event.key.keysym.sym == SDLK_LEFT)
					{      per.pos.x -= 10;
                                               break;
					}
					else if (event.key.keysym.sym == SDLK_UP)
					{
						per.pos.y -= 10;
                                                break;
					}
					else if (event.key.keysym.sym == SDLK_l)
					{
						per.pos.y += 10;
                                               break;
					}

		}
		}
	/*****MISE AJOURS*****/
		//Deplacement
		deplacer_enmie(&e);
                deplacer_enmie2(&e2);

		//Animation
		annimer_enmie(&e);
                annimer_enmie(&e2);
                annimerBonus(&b);
		for(int i=0 ; i<10 ; i++)
		{
			if(collision_trigo(per.pos , b.pos[i]) == 0)
			{
				b.etat[i]=0;
                                 per.p=2;
			}
		}
		
                if(collision_trigo(per.pos , e.pos)== 0||collision_trigo(per.pos , e2.pos) == 0)
			{
				
                                per.p=1;
			}
                
                  if(collision_trigo(per.pos , e2.pos) != 0 && collision_trigo(per.pos , e.pos) != 0)
			{
				
                                per.p=0;
			}
                 


		SDL_Delay(100);
	}
/*****LIBERATION*****/
	SDL_FreeSurface(e.etat_droite.img);
	SDL_FreeSurface(e.etat_gauche.img);
        SDL_FreeSurface(e2.etat_droite.img);
	SDL_FreeSurface(e2.etat_gauche.img);
	SDL_FreeSurface(back);
        SDL_FreeSurface(image);
        liberer_perso(&per);
}
